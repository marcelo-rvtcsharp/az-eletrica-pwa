from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.models import Usuario, get_db
import os

SECRET_KEY = os.getenv("SECRET_KEY", "az-eletrica-secret-2026-change-in-production")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 dias

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def hash_senha(senha: str) -> str:
    return pwd_context.hash(senha)


def verificar_senha(senha: str, hash: str) -> bool:
    return pwd_context.verify(senha, hash)


def criar_token(data: dict) -> str:
    payload = data.copy()
    # JWT exige que "sub" seja string (RFC 7519) — o python-jose valida isso
    # de forma incondicional em jwt.decode() e rejeita qualquer token onde
    # "sub" tenha sido salvo como número.
    if "sub" in payload:
        payload["sub"] = str(payload["sub"])
    payload["exp"] = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def get_usuario_atual(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> Usuario:
    erro = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido")
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        sub = payload.get("sub")
        if sub is None:
            raise erro
        user_id = int(sub)
    except (JWTError, ValueError):
        raise erro
    usuario = db.query(Usuario).filter(Usuario.id == user_id).first()
    if not usuario or not usuario.ativo:
        raise erro
    return usuario


def exigir_admin(usuario: Usuario = Depends(get_usuario_atual)) -> Usuario:
    """Telas de gestão: só administradores (CEO, engenheiro). Diarista não entra."""
    if (usuario.perfil or "admin") == "diarista":
        raise HTTPException(status_code=403, detail="Acesso restrito ao escritório")
    return usuario


def exigir_diarista(usuario: Usuario = Depends(get_usuario_atual)) -> Usuario:
    if (usuario.perfil or "admin") != "diarista" or not usuario.eletricista_id:
        raise HTTPException(status_code=403, detail="Área do funcionário")
    return usuario
