const API = 'https://az-eletrica-backend.onrender.com';
window._TOKEN = localStorage.getItem('az_token') || null;

const Token = {
  get: () => window._TOKEN,
  set: (t) => { window._TOKEN = t; localStorage.setItem('az_token', t); },
  del: () => { window._TOKEN = null; localStorage.removeItem('az_token'); localStorage.removeItem('az_user'); },
};

async function req(method, path, body) {
  const token = window._TOKEN;
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = 'Bearer ' + token;
  const res = await fetch(API + path, {
    method, headers,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (res.status === 401) { logout(); return null; }
  if (!res.ok) { const e = await res.json().catch(() => ({})); throw new Error(e?.detail || 'Erro ' + res.status); }
  return res.json();
}

function fmtBR(v) { return Number(v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function fmtData(s) { if (!s) return '—'; return new Date(s + 'T12:00:00').toLocaleDateString('pt-BR'); }
function esc(s) { return String(s || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
// ── Toque tátil (vibração) ────────────────────────────────────
// Android: navigator.vibrate. iPhone (Safari 18+): o "switch" nativo gera um toque leve.
const VIB = { toque: 8, ok: [14, 50, 22], erro: [45, 60, 45], aviso: [22, 40, 22] };
let _hapIOS = null;
function vibrar(tipo = 'toque') {
  try {
    if (localStorage.getItem('az_vibrar') === '0') return;
    if (navigator.vibrate) { navigator.vibrate(VIB[tipo] || VIB.toque); return; }
    if (!/iP(hone|ad|od)/.test(navigator.userAgent)) return;
    if (!_hapIOS) {
      _hapIOS = document.createElement('label'); _hapIOS.setAttribute('aria-hidden', 'true');
      _hapIOS.style.cssText = 'position:fixed;width:1px;height:1px;opacity:0;pointer-events:none;left:-9px;top:-9px';
      _hapIOS.innerHTML = '<input type="checkbox" switch tabindex="-1">'; document.body.appendChild(_hapIOS);
    }
    const n = tipo === 'toque' ? 1 : 2;
    for (let i = 0; i < n; i++) setTimeout(() => _hapIOS.click(), i * 90);
  } catch { /* sem vibração neste aparelho */ }
}
document.addEventListener('click', e => {
  const b = e.target.closest('button, .nav-item, .bn-item, .mais-item, a.pt-btn, .pt-op, .pt-dia');
  if (b && !b.disabled) vibrar('toque');
}, { capture: true, passive: true });

function toast(msg, tipo) {
  vibrar(tipo === 'erro' ? 'erro' : tipo === 'aviso' ? 'aviso' : 'ok');
  const el = document.getElementById('toast');
  el.textContent = msg;
  el.className = 'toast show' + (tipo === 'erro' ? ' erro' : '');
  clearTimeout(el._t);
  el._t = setTimeout(() => el.classList.remove('show'), 3500);
}

const S = { tela: 'dashboard', orc: null, obras: [], eletricistas: [], orcamentos: [], dash: null, finAno: new Date().getFullYear(), finMes: new Date().getMonth() + 1 };

function mostrarLogin() {
  document.getElementById('app').style.display = 'none';
  const pt = document.getElementById('portal'); if (pt) { pt.style.display = 'none'; pt.innerHTML = ''; }
  pararSino();
  document.getElementById('login-screen').style.display = 'flex';
}

function logout() { Token.del(); mostrarLogin(); }

async function handleLogin(e) {
  e.preventDefault();
  const email = document.getElementById('login-email').value.trim();
  const senha = document.getElementById('login-senha').value.trim();
  const btn = document.getElementById('btn-login');
  btn.textContent = 'Entrando...'; btn.disabled = true;
  try {
    const res = await fetch(API + '/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'username=' + encodeURIComponent(email) + '&password=' + encodeURIComponent(senha),
    });
    const data = await res.json();
    if (!res.ok || !data.access_token) throw new Error(data.detail || 'E-mail ou senha incorretos');
    Token.set(data.access_token);
    localStorage.setItem('az_user', JSON.stringify(data.usuario));
    iniciarApp();
  } catch (err) {
    toast(err.message, 'erro');
  } finally {
    btn.textContent = 'Entrar'; btn.disabled = false;
  }
}

function iniciarApp() {
  if (usuarioLogado().perfil === 'diarista') { document.getElementById('login-screen').style.display = 'none'; iniciarPortal(); return; }
  mostrarUsuarioLogado();
  atualizarUsuarioLogado();   // pega nome/cargo atualizados do servidor
  montarNavMobile();
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('app').style.display = 'flex';
  const telaUrl = new URLSearchParams(location.search).get('tela');
  if (telaUrl) history.replaceState(null, '', '/');
  navegar(['apontamentos', 'obras', 'folha', 'ferramentas', 'equipe'].includes(telaUrl) ? telaUrl : 'dashboard');
  carregarDados();
  iniciarSino();
}

async function carregarDados() {
  try {
    const [obras, elet, orcs] = await Promise.all([
      req('GET', '/obras/'), req('GET', '/eletricistas/'), req('GET', '/orcamentos/'),
    ]);
    if (!obras) return;
    S.obras = obras || []; S.eletricistas = elet || [];
    S.orcamentos = orcs || [];
    if (S.tela !== 'dashboard') renderMain();   // o dashboard busca os próprios dados
  } catch (err) { toast('Erro ao carregar: ' + err.message, 'erro'); }
}

function navegar(tela) {
  S.tela = tela; S.orc = null;
  document.querySelectorAll('.nav-item').forEach(el =>
    el.classList.toggle('active', el.dataset.tela === tela)
  );
  atualizarNavMobile(); fecharMais();
  document.getElementById('main')?.scrollTo(0, 0);
  if (tela === 'dashboard') { carregarDash(); return; }   // sempre busca números atualizados
  renderMain();
}

// ── Navegação no celular: barra inferior + menu "Mais" ────────
const NAV_PRINCIPAL = ['dashboard', 'apontamentos', 'obras', 'folha'];
const NAV_CURTO = { dashboard: 'Início', apontamentos: 'Apontar', orcamentos: 'Orçamentos' };
function itensNav() {
  return [...document.querySelectorAll('.sidebar .nav-item')].map(el => ({
    tela: el.dataset.tela, nome: el.querySelector('span')?.textContent || el.dataset.tela,
    ico: (el.querySelector('i')?.className || 'ti ti-circle'),
  }));
}
function montarNavMobile() {
  const itens = itensNav();
  const bn = document.getElementById('bottom-nav');
  if (bn) bn.innerHTML = itens.filter(i => NAV_PRINCIPAL.includes(i.tela)).map(i =>
    `<button class="bn-item" data-tela="${i.tela}" onclick="navegar('${i.tela}')"><i class="${i.ico}" aria-hidden="true"></i><span>${NAV_CURTO[i.tela] || i.nome}</span></button>`).join('') +
    `<button class="bn-item" data-tela="_mais" onclick="abrirMais()"><i class="ti ti-menu-2" aria-hidden="true"></i><span>Mais</span></button>`;
  const g = document.getElementById('mais-grid');
  if (g) g.innerHTML = itens.map(i =>
    `<button class="mais-item" data-tela="${i.tela}" onclick="navegar('${i.tela}')"><i class="${i.ico}" aria-hidden="true"></i>${i.nome}</button>`).join('') +
    `<button class="mais-item" onclick="logout()"><i class="ti ti-logout" aria-hidden="true"></i>Sair</button>`;
  atualizarNavMobile();
}
function atualizarNavMobile() {
  const principal = NAV_PRINCIPAL.includes(S.tela);
  document.querySelectorAll('.bn-item').forEach(b => b.classList.toggle('active', b.dataset.tela === S.tela || (b.dataset.tela === '_mais' && !principal)));
  document.querySelectorAll('.mais-item').forEach(b => b.classList.toggle('active', b.dataset.tela === S.tela));
}
function abrirMais() { document.getElementById('mais-sheet')?.classList.add('open'); }
function fecharMais() { document.getElementById('mais-sheet')?.classList.remove('open'); }

// ── Botões que só têm ícone ganham o nome escrito ao lado ─────
function rotularBotoes(raiz) {
  (raiz || document).querySelectorAll('button.btn[title]').forEach(b => {
    if (b.dataset.rot || b.textContent.trim()) return;
    b.dataset.rot = '1';
    const sp = document.createElement('span'); sp.className = 'btn-lbl'; sp.textContent = b.title;
    b.appendChild(sp);
  });
}
new MutationObserver(() => rotularBotoes()).observe(document.documentElement, { childList: true, subtree: true });

function renderMain() {
  const main = document.getElementById('main');
  if (!main) return;
  if (S.orc) { renderEditorOrc(main); return; }
  switch (S.tela) {
    case 'dashboard': renderDash(main); break;
    case 'orcamentos': renderOrcs(main); break;
    case 'obras': renderObrasPage(main); break;
    case 'equipe': renderEquipePage(main); break;
    case 'apontamentos': renderApontamentos(main); break;
    case 'financeiro': carregarFinanceiro(); break;
    case 'folha': carregarFolha(); break;
    case 'despesas': carregarDespesas(); break;
    case 'ferramentas': carregarFerramentas(); break;
    case 'usuarios': carregarUsuarios(); break;
  }
}

// ── DASHBOARD ────────────────────────────────────────────────
function renderDash(main) {
  const d = S.dash;
  if (!d) { main.innerHTML = '<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>'; return; }
  const m = d.mes || {};
  const c = d.custos || {};
  const per = d.periodo || { ano: S.finAno, mes: S.finMes };
  const nomeMes = `${MESES[per.mes - 1]} de ${per.ano}`;
  const corSit = s => s === 'negativo' ? ['#ef4444', '#b91c1c'] : s === 'atencao' ? ['#f59e0b', '#a16207'] : ['#10b981', '#15803d'];

  let varTxt = 'sem lançamentos no mês anterior';
  if (m.total_mes_anterior) {
    const v = (m.total_diarias - m.total_mes_anterior) / m.total_mes_anterior * 100;
    varTxt = `${v >= 0 ? '▲' : '▼'} ${Math.abs(v).toFixed(0)}% vs mês anterior (R$ ${fmtBR(m.total_mes_anterior)})`;
  }

  const maxObra = Math.max(1, ...(d.obras_mes || []).map(o => o.gasto_mes));
  const obrasMesHTML = (d.obras_mes || []).map((o, i) => {
    const [cor, corTxt] = corSit(o.situacao);
    const contrato = o.valor_contratado > 0
      ? `contrato: ${o.percentual}% consumido · saldo <b style="color:${corTxt}">R$ ${fmtBR(o.saldo)}</b>`
      : `<span style="color:#b91c1c">sem contrato · total gasto R$ ${fmtBR(o.total_gasto)}</span>`;
    return `<div class="obra-item">
      <div style="width:22px;font-size:12px;color:var(--text-muted);font-weight:600">${i + 1}º</div>
      <div class="obra-info">
        <div class="obra-nome">${esc(o.nome)}</div>
        <div class="obra-loc">${contrato}</div>
        <div class="prog"><div class="prog-fill" style="width:${o.gasto_mes / maxObra * 100}%;background:#1d4ed8"></div></div>
      </div>
      <div class="obra-saldo">
        <div class="obra-val">R$ ${fmtBR(o.gasto_mes)}</div>
        <div class="obra-pct">${o.perc_do_mes}% do mês</div>
      </div>
    </div>`;
  }).join('') || '<p class="empty">Nenhum lançamento neste mês</p>';

  const maxF = Math.max(1, ...(d.funcionarios_mes || []).map(f => f.valor));
  const funcHTML = (d.funcionarios_mes || []).map(f => `
    <div class="apto-item link-cal" onclick="abrirCalendarioPorNome('${esc(f.nome)}')" title="Ver dias trabalhados">
      <div class="av" style="background:#dbeafe;color:#1d4ed8">${esc(f.nome.replace(/^ENC\./, '').slice(0, 2).toUpperCase())}</div>
      <div class="apto-info" style="flex:1">
        <div class="apto-nome">${esc(f.nome)}</div>
        <div class="prog" style="margin-top:4px"><div class="prog-fill" style="width:${f.valor / maxF * 100}%;background:#f59e0b"></div></div>
      </div>
      <div class="apto-r"><div class="apto-val">R$ ${fmtBR(f.valor)}</div><div class="apto-data">${f.dias} dia(s) · ${f.perc_do_mes}%</div></div>
    </div>`).join('') || '<p class="empty">Nenhum lançamento neste mês</p>';

  const geralHTML = (d.obras?.lista || []).filter(o => o.valor_contratado > 0).map(o => {
    const [cor, corTxt] = corSit(o.situacao);
    return `<div class="obra-item">
      <div class="obra-dot" style="background:${cor}"></div>
      <div class="obra-info">
        <div class="obra-nome">${esc(o.nome)}</div>
        <div class="obra-loc">contrato R$ ${fmtBR(o.valor_contratado)} · gasto R$ ${fmtBR(o.total_gasto)}</div>
        <div class="prog"><div class="prog-fill" style="width:${Math.min(o.percentual, 100)}%;background:${cor}"></div></div>
      </div>
      <div class="obra-saldo">
        <div class="obra-val" style="color:${corTxt}">${o.saldo >= 0 ? '+' : ''} R$ ${fmtBR(o.saldo)}</div>
        <div class="obra-pct">${o.percentual}% consumido</div>
      </div>
    </div>`;
  }).join('') || '<p class="empty">Nenhuma obra com contrato</p>';

  const ultHTML = (d.ultimos_apontamentos || []).slice(0, 8).map(a => `
    <div class="apto-item">
      <div class="av" style="background:#dbeafe;color:#1d4ed8">${esc((a.eletricista || '?').replace(/^ENC\./, '').slice(0, 2).toUpperCase())}</div>
      <div class="apto-info"><div class="apto-nome">${esc(a.eletricista)}</div><div class="apto-obra">${esc(a.obra)}</div></div>
      <div class="apto-r"><div class="apto-val">R$ ${fmtBR(a.valor)}</div><div class="apto-data">${fmtData(a.data)}</div></div>
    </div>`).join('') || '<p class="empty">Nenhum apontamento neste mês</p>';

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Dashboard</div><div class="topbar-sub">${nomeMes}${per.mes_atual ? ' · mês atual' : ''}</div></div>
      <div style="display:flex;gap:8px">
        <button class="btn" onclick="carregarDados();carregarDash()"><i class="ti ti-refresh" aria-hidden="true"></i> Atualizar</button>
        <button class="btn btn-p" onclick="navegar('apontamentos')"><i class="ti ti-plus" aria-hidden="true"></i> Apontar diária</button>
      </div>
    </div>
    <div class="content">
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:14px">
        ${seletorMes('carregarDash')}
        ${per.mes_atual ? '' : '<button class="btn" onclick="irMesAtual()"><i class="ti ti-calendar" aria-hidden="true"></i> Mês atual</button>'}
      </div>
      <div class="metrics">
        <div class="metric">
          <div class="metric-ico blue"><i class="ti ti-currency-real" aria-hidden="true"></i></div>
          <div class="metric-label">Mão de obra no mês</div>
          <div class="metric-val">R$ ${fmtBR(m.total_diarias)}</div>
          <div class="metric-sub">${varTxt}</div>
        </div>
        <div class="metric">
          <div class="metric-ico amber"><i class="ti ti-tools-kitchen-2" aria-hidden="true"></i></div>
          <div class="metric-label">Alimentação + outros custos</div>
          <div class="metric-val">R$ ${fmtBR((c.alimentacao || 0) + (c.outros || 0))}</div>
          <div class="metric-sub">alimentação R$ ${fmtBR(c.alimentacao)} · outros R$ ${fmtBR(c.outros)}</div>
        </div>
        <div class="metric">
          <div class="metric-ico green"><i class="ti ti-sum" aria-hidden="true"></i></div>
          <div class="metric-label">Custo total do mês</div>
          <div class="metric-val">R$ ${fmtBR(c.total)}</div>
          <div class="metric-sub">${m.lancamentos || 0} diárias em ${m.dias_com_lancamento || 0} dia(s) · ${m.funcionarios || 0} pessoa(s)</div>
        </div>
        <div class="metric">
          <div class="metric-ico red"><i class="ti ti-alert-triangle" aria-hidden="true"></i></div>
          <div class="metric-label">Saldo geral dos contratos</div>
          <div class="metric-val" style="color:${(d.obras?.saldo_geral || 0) >= 0 ? '#15803d' : '#b91c1c'}">R$ ${fmtBR(d.obras?.saldo_geral)}</div>
          <div class="metric-sub">${d.obras?.negativas || 0} estourada(s) · ${d.obras?.atencao || 0} em atenção · ${d.obras?.sem_contrato || 0} sem contrato</div>
        </div>
      </div>
      <div class="row2">
        <div class="card">
          <div class="card-header"><span class="card-title"><i class="ti ti-building-factory-2" aria-hidden="true"></i> Gasto por obra · ${MESES[per.mes - 1]}</span></div>
          ${obrasMesHTML}
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title"><i class="ti ti-users" aria-hidden="true"></i> Gasto por funcionário · ${MESES[per.mes - 1]}</span></div>
          ${funcHTML}
        </div>
      </div>
      <div class="row2" style="margin-top:16px">
        <div class="card">
          <div class="card-header"><span class="card-title"><i class="ti ti-chart-bar" aria-hidden="true"></i> Contratos (acumulado até hoje)</span></div>
          ${geralHTML}
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title"><i class="ti ti-clock-check" aria-hidden="true"></i> Últimos apontamentos · ${MESES[per.mes - 1]}</span></div>
          ${ultHTML}
        </div>
      </div>
    </div>`;
}

async function carregarDash() {
  if (S.tela !== 'dashboard') return;
  S.dash = null; renderMain();
  try { S.dash = await req('GET', `/dashboard/?ano=${S.finAno}&mes=${S.finMes}`); renderMain(); }
  catch (err) { toast('Erro ao carregar: ' + err.message, 'erro'); }
}
function irMesAtual() { const h = new Date(); S.finAno = h.getFullYear(); S.finMes = h.getMonth() + 1; carregarDash(); }

// ── APONTAMENTOS ─────────────────────────────────────────────
function renderApontamentos(main) {
  const elets = S.eletricistas.filter(e => e.status === 'Ativo');
  const obras = S.obras.filter(o => o.status === 'Em andamento');
  const hoje = new Date().toISOString().slice(0, 10);

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Novo apontamento</div><div class="topbar-sub">Lance diárias por eletricista e obra</div></div>
      <button class="btn" onclick="navegar('dashboard')"><i class="ti ti-arrow-left" aria-hidden="true"></i> Voltar</button>
    </div>
    <div class="content">
      <div class="card">
        <div class="card-title" style="margin-bottom:16px"><i class="ti ti-clock-check" aria-hidden="true"></i> Dados do apontamento</div>
        <div class="form-grid2">
          <div class="field">
            <label>Eletricista *</label>
            <select id="ap-elet">
              <option value="">Selecione...</option>
              ${elets.map(e => `<option value="${e.id}" data-valor="${e.valor_diaria}">${esc(e.nome)} (R$ ${fmtBR(e.valor_diaria)}/dia)</option>`).join('')}
            </select>
          </div>
          <div class="field">
            <label>Data *</label>
            <input type="date" id="ap-data" value="${hoje}" />
          </div>
        </div>
        <div class="field" style="margin-top:12px">
          <label>Observação (opcional)</label>
          <input type="text" id="ap-obs" placeholder="Ex: serviço pesado, chuva..." />
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <span class="card-title"><i class="ti ti-building-factory-2" aria-hidden="true"></i> Obras do dia</span>
          <button class="btn btn-p" onclick="addObraLinha()"><i class="ti ti-plus" aria-hidden="true"></i> Adicionar obra</button>
        </div>
        <div id="obras-linhas">
          ${gerarLinhaObra(obras, 0)}
        </div>
        <div id="preview-total" style="margin-top:12px;padding:12px;background:var(--surface-1);border-radius:8px;display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:13px;color:var(--text-secondary)">Total do dia</span>
          <span style="font-size:18px;font-weight:500;color:var(--text-primary)" id="total-dia">R$ 0,00</span>
        </div>
      </div>

      <div class="card">
        <div class="card-title" style="margin-bottom:14px"><i class="ti ti-bolt" aria-hidden="true"></i> Adicionais</div>
        <div id="adicionais-linhas"></div>
        <button class="btn" style="margin-top:8px" onclick="addAdicionalLinha()"><i class="ti ti-plus" aria-hidden="true"></i> Adicionar adicional</button>
      </div>

      <button class="btn btn-p" style="width:100%;padding:12px;font-size:14px;justify-content:center" onclick="salvarApontamento()">
        <i class="ti ti-device-floppy" aria-hidden="true"></i> Salvar apontamento
      </button>
    </div>`;

  document.getElementById('ap-elet').addEventListener('change', recalcTotal);
}

let _obraCount = 1;
let _adCount = 0;

function gerarLinhaObra(obras, idx) {
  return `<div class="linha-obra" id="lo-${idx}" style="display:flex;gap:8px;align-items:center;margin-bottom:8px">
    <select class="lo-obra" style="flex:1" onchange="recalcTotal()">
      <option value="">Selecione a obra...</option>
      ${obras.map(o => `<option value="${o.id}">${esc(o.nome)} — ${esc(o.cidade || '')}</option>`).join('')}
    </select>
    <input class="lo-valor" type="number" placeholder="R$ valor" step="0.01" style="width:110px" oninput="recalcTotal()" />
    <button class="btn" onclick="removerLinha('lo-${idx}')" title="Remover"><i class="ti ti-trash" aria-hidden="true"></i></button>
  </div>`;
}

function addObraLinha() {
  const obras = S.obras.filter(o => o.status === 'Em andamento');
  const cont = document.getElementById('obras-linhas');
  const div = document.createElement('div');
  div.innerHTML = gerarLinhaObra(obras, _obraCount++);
  cont.appendChild(div.firstElementChild);
}

function addAdicionalLinha() {
  const cont = document.getElementById('adicionais-linhas');
  const idx = _adCount++;
  const div = document.createElement('div');
  div.id = 'ad-' + idx;
  div.style.cssText = 'display:flex;gap:8px;align-items:center;margin-bottom:8px';
  div.innerHTML = `
    <select class="ad-tipo" style="width:160px">
      <option value="sabado_feriado">Sábado/Feriado</option>
      <option value="semana_pesada">Semana pesada</option>
      <option value="hora_extra">Hora extra</option>
      <option value="outro">Outro</option>
    </select>
    <input class="ad-desc" type="text" placeholder="Descrição" style="flex:1" />
    <input class="ad-valor" type="number" placeholder="R$ valor" step="0.01" style="width:110px" oninput="recalcTotal()" />
    <button class="btn" onclick="removerLinha('ad-${idx}')" title="Remover"><i class="ti ti-trash" aria-hidden="true"></i></button>`;
  cont.appendChild(div);
}

function removerLinha(id) {
  document.getElementById(id)?.remove();
  recalcTotal();
}

function recalcTotal() {
  let total = 0;
  document.querySelectorAll('.lo-valor').forEach(i => { total += parseFloat(i.value) || 0; });
  document.querySelectorAll('.ad-valor').forEach(i => { total += parseFloat(i.value) || 0; });
  const el = document.getElementById('total-dia');
  if (el) el.textContent = 'R$ ' + fmtBR(total);
}

async function salvarApontamento() {
  const elet_id = parseInt(document.getElementById('ap-elet').value);
  const data = document.getElementById('ap-data').value;
  const obs = document.getElementById('ap-obs').value;
  if (!elet_id || !data) { toast('Selecione o eletricista e a data', 'erro'); return; }

  const itens = [];
  document.querySelectorAll('.linha-obra').forEach(row => {
    const obra_id = parseInt(row.querySelector('.lo-obra').value);
    const valor = parseFloat(row.querySelector('.lo-valor').value);
    if (obra_id && valor > 0) itens.push({ obra_id, valor });
  });
  if (itens.length === 0) { toast('Adicione pelo menos uma obra', 'erro'); return; }

  const adicionais = [];
  document.querySelectorAll('[id^="ad-"]').forEach(row => {
    const tipo = row.querySelector('.ad-tipo')?.value;
    const desc = row.querySelector('.ad-desc')?.value;
    const valor = parseFloat(row.querySelector('.ad-valor')?.value);
    if (tipo && desc && valor > 0) adicionais.push({ tipo, descricao: desc, valor });
  });

  try {
    await req('POST', '/apontamentos/', { eletricista_id: elet_id, data, observacao: obs, itens, adicionais });
    toast('Apontamento salvo!');
    _obraCount = 1; _adCount = 0;
    navegar('dashboard');
    carregarDados();
  } catch (err) { toast(err.message, 'erro'); }
}

// ── OBRAS ────────────────────────────────────────────────────
function renderObrasPage(main) {
  const pedidas = S.obras.filter(o => o.status === 'Solicitada');
  const avisoPedidas = pedidas.length ? `<div class="aviso-pedidas"><i class="ti ti-map-pin-plus" aria-hidden="true"></i><div><b>${pedidas.length} obra(s) pedida(s) pela equipe</b><br><span>Aprove preenchendo cliente e valor, ou junte com uma obra que já existe (se foi só nome diferente).</span></div></div>` : '';
  const cards = [...pedidas, ...S.obras.filter(o => o.status !== 'Solicitada')].map(o => {
    if (o.status === 'Solicitada') return `<div class="obra-card obra-pedida">
      <div class="obra-card-top"><div class="obra-card-header"><div class="obra-card-nome">${esc(o.nome)}</div><span class="badge b-a">Pedida pela equipe</span></div>
        <div class="obra-card-loc"><i class="ti ti-map-pin" aria-hidden="true"></i> ${esc(o.cidade || 'Cidade não informada')}</div></div>
      <div class="obra-fin"><div style="font-size:12px;color:var(--text-muted);line-height:1.45">${esc(o.observacoes || '')}</div>
        <div class="fin-row" style="margin-top:8px"><span class="fin-label">Diárias já lançadas</span><span class="fin-val">R$ ${fmtBR(o.total_gasto)}</span></div></div>
      <div class="obra-card-footer" style="gap:6px;flex-wrap:wrap">
        <button class="btn" onclick="abrirJuntarObra(${o.id})"><i class="ti ti-arrow-merge" aria-hidden="true"></i> Juntar com…</button>
        <div style="display:flex;gap:6px">
          <button class="btn" onclick="excluirObra(${o.id}, '${esc(o.nome)}')" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
          <button class="btn btn-p" onclick="editarObra(${o.id})"><i class="ti ti-check" aria-hidden="true"></i> Aprovar</button></div></div></div>`;
    const cor = o.situacao === 'negativo' ? '#ef4444' : o.situacao === 'atencao' ? '#f59e0b' : '#10b981';
    const corTxt = o.situacao === 'negativo' ? '#b91c1c' : o.situacao === 'atencao' ? '#a16207' : '#15803d';
    const bc = o.situacao === 'negativo' ? 'b-r' : o.situacao === 'atencao' ? 'b-a' : 'b-g';
    const lb = o.situacao === 'negativo' ? 'Negativa' : o.situacao === 'atencao' ? 'Atenção' : 'Em dia';
    return `<div class="obra-card">
      <div class="obra-card-top">
        <div class="obra-card-header">
          <div class="obra-card-nome">${esc(o.nome)}</div>
          <span class="badge ${bc}">${lb}</span>
        </div>
        <div class="obra-card-loc"><i class="ti ti-map-pin" aria-hidden="true"></i> ${esc(o.cidade || '')} · ${esc(o.cliente)}</div>
      </div>
      <div class="obra-fin">
        <div class="fin-row"><span class="fin-label">Contratado</span><span class="fin-val">R$ ${fmtBR(o.valor_contratado)}</span></div>
        <div class="fin-row"><span class="fin-label">Gasto em diárias</span><span class="fin-val">R$ ${fmtBR(o.total_gasto)}</span></div>
        <div class="fin-row"><span class="fin-label">Saldo</span><span class="fin-val" style="color:${corTxt}">R$ ${fmtBR(o.saldo)}</span></div>
        <div class="prog" style="margin-top:8px"><div class="prog-fill" style="width:${Math.min(o.percentual_consumido || 0, 100)}%;background:${cor}"></div></div>
        <div style="font-size:10px;color:var(--text-muted);margin-top:3px">${o.percentual_consumido || 0}% consumido</div>
      </div>
      <div class="obra-card-footer">
        <span style="font-size:11px;color:var(--text-muted)">${esc(o.tipo_servico || '')}</span>
        <div style="display:flex;gap:6px">
          <button class="btn" onclick="editarObra(${o.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
          <button class="btn" onclick="excluirObra(${o.id}, '${esc(o.nome)}')" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
        </div>
      </div>
    </div>`;
  }).join('') || '<p class="empty">Nenhuma obra cadastrada</p>';

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Obras</div><div class="topbar-sub">${S.obras.length} cadastradas</div></div>
      <div style="display:flex;gap:8px">
        <button class="btn" onclick="zerarObras()" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i> Zerar obras</button>
        <button class="btn btn-p" onclick="abrirModalObra()"><i class="ti ti-plus" aria-hidden="true"></i> Nova obra</button>
      </div>
    </div>
    <div class="content">${avisoPedidas}<div class="obras-grid">${cards}</div></div>`;
}

function abrirJuntarObra(id) {
  const o = S.obras.find(x => x.id === id);
  const outras = S.obras.filter(x => x.id !== id && x.status !== 'Solicitada').sort((a, b) => a.nome.localeCompare(b.nome));
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">Juntar "${esc(o.nome)}"</span><button class="btn" onclick="fecharModal()" aria-label="Fechar"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <p style="font-size:13px;color:var(--text-muted);margin:0 0 10px">As diárias (R$ ${fmtBR(o.total_gasto)}), despesas e ferramentas desta obra passam para a obra escolhida, e "${esc(o.nome)}" é apagada.</p>
        <div class="field"><label>É a mesma obra que</label><select id="jo-dest">${outras.map(x => `<option value="${x.id}">${esc(x.nome)}</option>`).join('')}</select></div>
        <div class="modal-footer"><button class="btn" onclick="fecharModal()">Cancelar</button><button class="btn btn-p" onclick="juntarObra(${id})"><i class="ti ti-arrow-merge" aria-hidden="true"></i> Juntar</button></div>
      </div>
    </div>`;
}
async function juntarObra(id) {
  const dest = +document.getElementById('jo-dest').value; if (!dest) return;
  try {
    const d = await req('POST', `/obras/${id}/juntar`, { destino_id: dest });
    S.obras = S.obras.filter(o => o.id !== id).map(o => o.id === d.id ? d : o);
    fecharModal(); toast('Obras juntadas!'); renderMain();
  } catch (err) { toast(err.message, 'erro'); }
}

function abrirModalObra(id) {
  const o = id ? S.obras.find(x => x.id === id) : null;
  const titulo = o ? 'Editar obra' : 'Nova obra';
  const html = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${titulo}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        ${o?.status === 'Solicitada' ? '<p class="aviso-inline"><i class="ti ti-info-circle" aria-hidden="true"></i> Obra pedida pela equipe. Confira o nome, preencha cliente e valor e salve para aprovar.</p>' : ''}
        <div class="field"><label>Nome da obra *</label><input id="m-nome" value="${esc(o?.nome || '')}" placeholder="Ex: Residência João Silva" /></div>
        <div class="form-grid2">
          <div class="field"><label>Cliente *</label><input id="m-cliente" value="${esc(o?.cliente === 'A definir' ? '' : (o?.cliente || ''))}" placeholder="Nome do cliente" /></div>
          <div class="field"><label>Contato</label><input id="m-contato" value="${esc(o?.contato || '')}" placeholder="(88) 9 0000-0000" /></div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Cidade *</label><input id="m-cidade" value="${esc(o?.cidade || '')}" placeholder="Ex: Amontada" /></div>
          <div class="field"><label>Bairro</label><input id="m-bairro" value="${esc(o?.bairro || '')}" placeholder="Ex: Centro" /></div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Valor contratado (R$) *</label><input id="m-valor" type="number" value="${o?.valor_contratado || ''}" placeholder="0,00" /></div>
          <div class="field"><label>Tipo de serviço</label>
            <select id="m-tipo">
              ${['Elétrica residencial','Elétrica comercial','Elétrica industrial','SPDA / Para-raios','Iluminação pública','Outro'].map(t => `<option ${o?.tipo_servico === t ? 'selected' : ''}>${t}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Início</label><input id="m-inicio" type="date" value="${o?.data_inicio || ''}" /></div>
          <div class="field"><label>Previsão de término</label><input id="m-prev" type="date" value="${o?.data_previsao || ''}" /></div>
        </div>
        <div class="field"><label>Observações</label><textarea id="m-obs" placeholder="Ex: Inclui fornecimento de material...">${esc(o?.observacoes || '')}</textarea></div>
        <div class="field"><label>Alerta de consumo (%)</label>
          <select id="m-alerta">
            <option ${o?.alerta_percentual === 70 ? 'selected' : ''} value="70">70% — Aviso antecipado</option>
            <option ${(!o || o?.alerta_percentual === 85) ? 'selected' : ''} value="85">85% — Padrão</option>
            <option ${o?.alerta_percentual === 95 ? 'selected' : ''} value="95">95% — Somente crítico</option>
          </select>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarObra(${o?.id || 'null'})">${o ? 'Salvar alterações' : 'Cadastrar obra'}</button>
        </div>
      </div>
    </div>`;
  document.getElementById('modal-root').innerHTML = html;
}

function editarObra(id) { abrirModalObra(id); }

async function salvarObra(id) {
  const data = {
    nome: document.getElementById('m-nome').value,
    cliente: document.getElementById('m-cliente').value,
    contato: document.getElementById('m-contato').value,
    cidade: document.getElementById('m-cidade').value,
    bairro: document.getElementById('m-bairro').value,
    valor_contratado: parseFloat(document.getElementById('m-valor').value) || 0,
    tipo_servico: document.getElementById('m-tipo').value,
    data_inicio: document.getElementById('m-inicio').value || null,
    data_previsao: document.getElementById('m-prev').value || null,
    observacoes: document.getElementById('m-obs').value,
    alerta_percentual: parseInt(document.getElementById('m-alerta').value),
    status: 'Em andamento',
  };
  if (!data.nome || !data.cliente || !data.valor_contratado) { toast('Preencha os campos obrigatórios', 'erro'); return; }
  try {
    if (id) {
      const u = await req('PUT', `/obras/${id}`, data);
      S.obras = S.obras.map(o => o.id === id ? u : o);
    } else {
      const nova = await req('POST', '/obras/', data);
      S.obras = [nova, ...S.obras];
    }
    fecharModal(); toast(id ? 'Obra atualizada!' : 'Obra cadastrada!');
    renderMain();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirObra(id, nome) {
  if (!confirm(`Excluir a obra "${nome}"?\nOs apontamentos lançados nesta obra também serão excluídos.`)) return;
  try {
    await req('DELETE', `/obras/${id}`);
    S.obras = S.obras.filter(o => o.id !== id);
    toast('Obra excluída!'); renderMain();
  } catch (err) { toast(err.message, 'erro'); }
}

async function zerarObras() {
  if (!confirm('Excluir TODAS as obras? Esta ação não pode ser desfeita.')) return;
  try {
    for (const o of [...S.obras]) {
      await req('DELETE', `/obras/${o.id}`);
      S.obras = S.obras.filter(x => x.id !== o.id);
    }
    toast('Obras zeradas!');
  } catch (err) { toast(err.message, 'erro'); }
  renderMain();
}

// ── EQUIPE ────────────────────────────────────────────────────
function renderEquipePage(main) {
  const fb = { Encarregado: 'b-a', Eletricista: 'b-g', Auxiliar: '' };
  const linhas = S.eletricistas.map(e => `
    <tr style="${e.status !== 'Ativo' ? 'opacity:.55' : ''}">
      <td>
        <div class="elet-cell">
          <div class="av" style="background:#dbeafe;color:#1d4ed8">${e.nome.slice(0, 2).toUpperCase()}</div>
          <div class="link-cal" onclick="abrirCalendario(${e.id})" title="Ver dias trabalhados"><div style="font-size:13px;font-weight:500;color:var(--text-primary)">${esc(e.nome)} <i class="ti ti-calendar-event" aria-hidden="true" style="color:#9aa5b4;font-size:13px"></i></div><div style="font-size:11px;color:var(--text-muted)">${esc(e.telefone || '')}</div></div>
        </div>
      </td>
      <td><span class="badge ${fb[e.funcao] || ''}">${esc(e.funcao)}</span></td>
      <td style="font-weight:500;color:var(--text-primary)">${e.tipo_contrato === 'Mensalista' ? 'R$ ' + fmtBR(e.salario_fixo) + '<span style="font-size:11px;color:var(--text-muted)">/mês</span>' : 'R$ ' + fmtBR(e.valor_diaria)}</td>
      <td><span class="badge ${e.status === 'Ativo' ? 'b-g' : ''}">${esc(e.status)}</span></td>
      <td>
        <div style="display:flex;gap:4px;justify-content:flex-end">
          <button class="btn" onclick="abrirCalendario(${e.id})" title="Dias"><i class="ti ti-calendar-event" aria-hidden="true"></i></button>
          <button class="btn" onclick="editarElet(${e.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
          <button class="btn" onclick="excluirElet(${e.id}, '${esc(e.nome)}')" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
        </div>
      </td>
    </tr>`).join('');

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Equipe</div><div class="topbar-sub">${S.eletricistas.length} cadastrados · ${S.eletricistas.filter(e => e.status === 'Ativo').length} ativos</div></div>
      <div style="display:flex;gap:8px">
        <button class="btn" onclick="zerarEquipe()" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i> Zerar equipe</button>
        <button class="btn btn-p" onclick="abrirModalElet()"><i class="ti ti-plus" aria-hidden="true"></i> Novo membro</button>
      </div>
    </div>
    <div class="content">
      <div class="table-card">
        <table class="tbl-cards">
          <thead><tr><th>Membro</th><th>Função</th><th>Valor/dia ou fixo</th><th>Status</th><th></th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="5" class="empty">Nenhum cadastrado</td></tr>'}</tbody>
        </table>
      </div>
    </div>`;
}

function abrirModalElet(id) {
  const e = id ? S.eletricistas.find(x => x.id === id) : null;
  const titulo = e ? 'Editar membro' : 'Novo membro';
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${titulo}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="field"><label>Nome completo *</label><input id="me-nome" value="${esc(e?.nome || '')}" placeholder="Ex: João Lima Junior" /></div>
        <div class="form-grid2">
          <div class="field"><label>Telefone / WhatsApp</label><input id="me-tel" value="${esc(e?.telefone || '')}" placeholder="(88) 9 0000-0000" /></div>
          <div class="field"><label>CPF</label><input id="me-cpf" value="${esc(e?.cpf || '')}" placeholder="000.000.000-00" /></div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Função *</label>
            <select id="me-funcao">
              ${['Encarregado','Eletricista','Auxiliar','Estagiário'].map(f => `<option ${e?.funcao === f ? 'selected' : ''}>${f}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Valor da diária (R$) *</label><input id="me-valor" type="number" value="${e?.valor_diaria || ''}" placeholder="200,00" /></div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Tipo de contrato</label>
            <select id="me-contrato" onchange="document.getElementById('me-fixo-box').style.display=this.value==='Mensalista'?'':'none'">
              ${['Diarista','Mensalista','PJ'].map(t => `<option ${e?.tipo_contrato === t ? 'selected' : ''}>${t}</option>`).join('')}
            </select>
          </div>
          <div class="field"><label>Status</label>
            <select id="me-status">
              ${['Ativo','Inativo','Afastado'].map(s => `<option ${e?.status === s ? 'selected' : ''}>${s}</option>`).join('')}
            </select>
          </div>
        </div>
        <div class="field" id="me-fixo-box" style="${e?.tipo_contrato === 'Mensalista' ? '' : 'display:none'}">
          <label>Salário fixo mensal (R$) *</label><input id="me-fixo" type="number" step="0.01" value="${e?.salario_fixo || ''}" placeholder="5.500,00" />
          <div style="font-size:11px;color:var(--text-muted);margin-top:4px">Na folha, mensalista recebe só o fixo + adicionais. A diária acima serve apenas para o custo das obras.</div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>NR-10 válido até</label><input id="me-nr10" type="date" value="${e?.nr10_validade || ''}" /></div>
          <div class="field"><label>NR-35 válido até</label><input id="me-nr35" type="date" value="${e?.nr35_validade || ''}" /></div>
        </div>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarElet(${e?.id || 'null'})">${e ? 'Salvar alterações' : 'Cadastrar membro'}</button>
        </div>
      </div>
    </div>`;
}

function editarElet(id) { abrirModalElet(id); }

async function salvarElet(id) {
  const data = {
    nome: document.getElementById('me-nome').value,
    telefone: document.getElementById('me-tel').value,
    cpf: document.getElementById('me-cpf').value,
    funcao: document.getElementById('me-funcao').value,
    valor_diaria: parseFloat(document.getElementById('me-valor').value) || 0,
    tipo_contrato: document.getElementById('me-contrato').value,
    salario_fixo: parseFloat(document.getElementById('me-fixo')?.value) || 0,
    status: document.getElementById('me-status').value,
    nr10_validade: document.getElementById('me-nr10').value || null,
    nr35_validade: document.getElementById('me-nr35').value || null,
  };
  if (!data.nome) { toast('Preencha o nome', 'erro'); return; }
  if (data.tipo_contrato === 'Mensalista') {
    if (!data.salario_fixo) { toast('Preencha o salário fixo do mensalista', 'erro'); return; }
  } else if (!data.valor_diaria) { toast('Preencha o valor da diária', 'erro'); return; }
  try {
    if (id) {
      const u = await req('PUT', `/eletricistas/${id}`, data);
      S.eletricistas = S.eletricistas.map(e => e.id === id ? u : e);
    } else {
      const novo = await req('POST', '/eletricistas/', data);
      S.eletricistas = [...S.eletricistas, novo];
    }
    fecharModal(); toast(id ? 'Membro atualizado!' : 'Membro cadastrado!');
    renderMain();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirElet(id, nome) {
  if (!confirm(`Excluir "${nome}" da equipe?\nTodos os apontamentos dessa pessoa também serão excluídos.`)) return;
  try {
    await req('DELETE', `/eletricistas/${id}`);
    S.eletricistas = S.eletricistas.filter(e => e.id !== id);
    toast('Membro excluído!'); renderMain();
  } catch (err) { toast(err.message, 'erro'); }
}

async function zerarEquipe() {
  if (!confirm('Excluir TODOS os membros da equipe? Esta ação não pode ser desfeita.')) return;
  try {
    for (const e of [...S.eletricistas]) {
      await req('DELETE', `/eletricistas/${e.id}`);
      S.eletricistas = S.eletricistas.filter(x => x.id !== e.id);
    }
    toast('Equipe zerada!');
  } catch (err) { toast(err.message, 'erro'); }
  renderMain();
}

// ── ORÇAMENTOS ────────────────────────────────────────────────
function renderOrcs(main) {
  const bc = { Rascunho: 'bs-r', Enviado: 'bs-e', Aprovado: 'bs-a', Reprovado: 'bs-rep' };
  const total = S.orcamentos.reduce((a, o) => a + (o.total || 0), 0);
  const aprov = S.orcamentos.filter(o => o.status === 'Aprovado').reduce((a, o) => a + o.total, 0);
  const env = S.orcamentos.filter(o => o.status === 'Enviado').reduce((a, o) => a + o.total, 0);
  const rasc = S.orcamentos.filter(o => o.status === 'Rascunho').length;

  const linhas = S.orcamentos.map(o => `
    <tr onclick="abrirOrc(${o.id})" style="cursor:pointer">
      <td data-label="Nº" style="font-size:11px;color:var(--text-muted);font-family:monospace">${esc(o.numero || '')}</td>
      <td class="td-titulo" style="font-size:13px;font-weight:500;color:var(--text-primary)">${esc(o.cliente_nome || '—')}</td>
      <td data-label="Obra" style="font-size:11px;color:var(--text-muted)">${esc(o.obra_descricao || '—')}</td>
      <td data-label="Data" style="font-size:11px;color:var(--text-muted)">${fmtData(o.data)}</td>
      <td data-label="Total" class="td-destaque" style="text-align:right;font-size:13px;font-weight:500">R$ ${fmtBR(o.total)}</td>
      <td data-label="Status"><span class="badge ${bc[o.status] || ''}">${o.status}</span></td>
      <td class="td-acoes">
        <div style="display:flex;gap:4px;justify-content:flex-end">
          <button class="btn" onclick="event.stopPropagation();dupOrc(${o.id})" title="Duplicar"><i class="ti ti-copy" aria-hidden="true"></i></button>
          <button class="btn btn-whats" onclick="event.stopPropagation();pdfOrc(${o.id})" title="PDF / Enviar pelo WhatsApp"><i class="ti ti-brand-whatsapp" aria-hidden="true"></i></button>
          <button class="btn" onclick="event.stopPropagation();delOrc(${o.id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
        </div>
      </td>
    </tr>`).join('');

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Orçamentos</div><div class="topbar-sub">${S.orcamentos.length} orçamentos</div></div>
      <button class="btn btn-p" onclick="novoOrc()"><i class="ti ti-plus" aria-hidden="true"></i> Novo orçamento</button>
    </div>
    <div class="content">
      <div class="metrics">
        <div class="metric"><div class="metric-label">Total orçado</div><div class="metric-val">R$ ${fmtBR(total)}</div></div>
        <div class="metric"><div class="metric-label">Aprovados</div><div class="metric-val" style="color:#15803d">R$ ${fmtBR(aprov)}</div></div>
        <div class="metric"><div class="metric-label">Aguardando</div><div class="metric-val" style="color:#1d4ed8">R$ ${fmtBR(env)}</div></div>
        <div class="metric"><div class="metric-label">Rascunhos</div><div class="metric-val" style="color:var(--text-muted)">${rasc}</div></div>
      </div>
      <div class="table-card">
        <table class="tbl-lista">
          <thead><tr><th>Nº</th><th>Cliente</th><th>Obra</th><th>Data</th><th style="text-align:right">Total</th><th>Status</th><th></th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="7" class="empty">Nenhum orçamento</td></tr>'}</tbody>
        </table>
      </div>
    </div>`;
}

async function novoOrc() {
  try {
    const o = await req('POST', '/orcamentos/', { data: new Date().toISOString().slice(0, 10), status: 'Rascunho', itens: [] });
    S.orcamentos = [o, ...S.orcamentos]; S.orc = o; renderMain();
  } catch (err) { toast(err.message, 'erro'); }
}

function abrirOrc(id) { S.orc = S.orcamentos.find(o => o.id === id) || null; renderMain(); }
function fecharOrc() { S.orc = null; carregarDados(); }

function totalOrc() { return (S.orc?.itens || []).reduce((a, it) => a + (parseFloat(it.qtd) || 0) * (parseFloat(it.vunit) || 0), 0); }
function updOrcCampo(f, v) { S.orc = { ...S.orc, [f]: v }; atualizarTotalFixo(); }
function updOrcCliente(f, v) { S.orc = { ...S.orc, [f]: v }; if (f === 'cliente_nome') { const el = document.querySelector('.editor-titulo'); if (el) el.textContent = v || 'Novo orçamento'; } }
function updItem(i, f, v) { const itens = [...S.orc.itens]; itens[i] = { ...itens[i], [f]: v }; S.orc = { ...S.orc, itens }; atualizarTotalFixo(); const c = document.getElementById('chip-' + i); if (c) { const vt = (parseFloat(itens[i].qtd) || 0) * (parseFloat(itens[i].vunit) || 0); c.textContent = 'R$ ' + fmtBR(vt); } }
function delItem(i) { S.orc = { ...S.orc, itens: S.orc.itens.filter((_, x) => x !== i) }; renderMain(); }
function addItem() { const desc = (document.getElementById('n-desc')?.value || '').trim(); const und = document.getElementById('n-und')?.value || 'UND'; const qtd = parseFloat(document.getElementById('n-qtd')?.value) || 0; const vunit = parseFloat(document.getElementById('n-vunit')?.value) || 0; if (!desc) { toast('Preencha a descrição', 'erro'); return; } S.orc = { ...S.orc, itens: [...S.orc.itens, { descricao: desc, und, qtd, vunit }] }; renderMain(); }
function atualizarTotalFixo() { const t = totalOrc(); const el = document.querySelector('.total-fixo-valor'); if (el) el.textContent = 'R$ ' + fmtBR(t); const tv = document.querySelector('.tv'); if (tv) tv.textContent = 'R$ ' + fmtBR(t); }
function prevItem() { const qtd = parseFloat(document.getElementById('n-qtd')?.value) || 0; const vunit = parseFloat(document.getElementById('n-vunit')?.value) || 0; const prev = qtd * vunit; const bar = document.getElementById('preview-bar'); if (!bar) return; if (prev > 0) { const tot = totalOrc() + prev; bar.innerHTML = `<div class="preview-bar"><span style="color:var(--text-muted);font-size:12px">Este item:</span><span style="font-weight:500;color:#1d4ed8;font-size:12px;flex:1;margin-left:6px">+ R$ ${fmtBR(prev)}</span><span style="font-size:12px;color:var(--text-muted)">→ Total:</span><span style="font-weight:500;color:var(--text-primary);font-size:12px;margin-left:6px">R$ ${fmtBR(tot)}</span></div>`; } else bar.innerHTML = ''; }

async function salvarOrc(silencioso) {
  const o = S.orc; if (!o) return;
  try {
    const u = await req('PUT', `/orcamentos/${o.id}`, { cliente_nome: o.cliente_nome, cliente_cnpj: o.cliente_cnpj, cliente_endereco: o.cliente_endereco, obra_descricao: o.obra_descricao, data: o.data, validade: parseInt(o.validade) || 10, status: o.status, obs: o.obs, itens: (o.itens || []).map((it, i) => ({ descricao: it.descricao, und: it.und, qtd: parseFloat(it.qtd) || 0, vunit: parseFloat(it.vunit) || 0, ordem: i })) });
    S.orc = u; S.orcamentos = S.orcamentos.map(x => x.id === u.id ? u : x);
    if (silencioso) return u;
    toast('Salvo!'); renderMain();
  } catch (err) { if (silencioso) throw err; toast(err.message, 'erro'); }
}

async function dupOrc(id) { const o = S.orcamentos.find(x => x.id === id); if (!o) return; try { const c = await req('POST', '/orcamentos/', { cliente_nome: (o.cliente_nome || '') + ' (cópia)', cliente_cnpj: o.cliente_cnpj, cliente_endereco: o.cliente_endereco, obra_descricao: o.obra_descricao, data: new Date().toISOString().slice(0, 10), validade: o.validade, status: 'Rascunho', obs: o.obs, itens: (o.itens || []).map((it, i) => ({ descricao: it.descricao, und: it.und, qtd: it.qtd, vunit: it.vunit, ordem: i })) }); S.orcamentos = [c, ...S.orcamentos]; S.orc = c; toast('Duplicado!'); renderMain(); } catch (err) { toast(err.message, 'erro'); } }
async function delOrc(id) { if (!confirm('Excluir este orçamento?')) return; try { await req('DELETE', `/orcamentos/${id}`); S.orcamentos = S.orcamentos.filter(o => o.id !== id); if (S.orc?.id === id) S.orc = null; toast('Excluído!'); renderMain(); } catch (err) { toast(err.message, 'erro'); } }
// PDF do orçamento: gerado no servidor (com a marca) e enviado como arquivo
async function pdfOrc(id) {
  const noEditor = S.orc && S.orc.id === id;
  document.getElementById('modal-root').innerHTML = `<div class="modal-overlay"><div class="modal" style="max-width:380px;text-align:center"><div class="spinner" style="margin:10px auto"></div><p style="font-size:13px;color:var(--text-muted)">${noEditor ? 'Salvando e gerando' : 'Gerando'} o PDF...</p></div></div>`;
  try {
    if (noEditor) await salvarOrc(true);
    const o = (noEditor ? S.orc : S.orcamentos.find(x => x.id === id)) || {};
    const { blob } = await reqArquivo(`/orcamentos/${id}/pdf`);
    const cli = (o.cliente_nome || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w]+/g, '_').replace(/^_|_$/g, '').slice(0, 40);
    S.orcPdf = { arquivo: new File([blob], `Orcamento_${o.numero || id}${cli ? '_' + cli : ''}.pdf`, { type: 'application/pdf' }), orc: o };
    const total = (o.itens || []).reduce((a, it) => a + (parseFloat(it.qtd) || 0) * (parseFloat(it.vunit) || 0), 0);
    modalPdfPronto(S.orcPdf.arquivo, `${o.cliente_nome || 'Sem cliente'} · R$ ${fmtBR(total)}`, () => marcarOrcEnviado(o),
      `Olá${o.cliente_nome ? ', ' + o.cliente_nome : ''}! Segue o orçamento ${o.numero || ''}${o.obra_descricao ? ' (' + o.obra_descricao + ')' : ''} da AZ Elétrica. Qualquer dúvida, estamos à disposição.`);
  } catch (err) { fecharModal(); toast(err.message, 'erro'); }
}

// Modal "PDF pronto": enviar pelo WhatsApp (folha de compartilhar do celular), ver ou baixar
function modalPdfPronto(arquivo, info, aposEnviar, texto) {
  S.pdfPronto = { arquivo, aposEnviar, texto };
  const podeCompartilhar = !!(navigator.canShare && navigator.canShare({ files: [arquivo] }));
  {
    document.getElementById('modal-root').innerHTML = `
      <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
        <div class="modal" style="max-width:420px">
          <div class="modal-header"><span class="modal-title">PDF pronto</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
          <div class="pdf-pronto"><i class="ti ti-file-type-pdf" aria-hidden="true"></i><div style="min-width:0"><div class="pp-nome">${esc(arquivo.name)}</div>
            <div class="pp-info">${esc(info || '')}</div></div></div>
          <button class="btn btn-whats btn-full" onclick="enviarPdfWhats()"><i class="ti ti-brand-whatsapp" aria-hidden="true"></i> Enviar pelo WhatsApp</button>
          <p style="font-size:11.5px;color:var(--text-muted);margin:6px 2px 12px">${podeCompartilhar ? 'Escolha o WhatsApp na lista e depois a conversa. O PDF vai anexado.' : 'No computador: o PDF é baixado e o WhatsApp abre para você escolher a conversa e anexar o arquivo (clipe 📎).'}</p>
          <div style="display:flex;gap:8px">
            <button class="btn" style="flex:1;justify-content:center" onclick="abrirPdfPronto()"><i class="ti ti-eye" aria-hidden="true"></i> Ver PDF</button>
            <button class="btn" style="flex:1;justify-content:center" onclick="baixarArquivo(S.pdfPronto.arquivo)"><i class="ti ti-download" aria-hidden="true"></i> Baixar</button>
          </div>
        </div>
      </div>`;
  }
}

function abrirPdfPronto() {
  if (!S.pdfPronto) return;
  const u = URL.createObjectURL(S.pdfPronto.arquivo);
  if (!window.open(u, '_blank')) window.location.href = u;
}

function enviarPdfWhats() {
  const p = S.pdfPronto; if (!p) return;
  if (navigator.canShare && navigator.canShare({ files: [p.arquivo] })) {
    // chamado direto no toque (sem await antes) para o celular abrir a lista de apps
    navigator.share({ files: [p.arquivo], title: p.arquivo.name.replace(/\.pdf$/, '') })
      .then(() => { fecharModal(); p.aposEnviar && p.aposEnviar(); })
      .catch(err => { if (err?.name !== 'AbortError') toast('Não foi possível compartilhar: ' + err.message, 'erro'); });
    return;
  }
  baixarArquivo(p.arquivo);
  window.open(`https://wa.me/?text=${encodeURIComponent(p.texto || '')}`, '_blank');
  toast('PDF baixado. No WhatsApp, escolha a conversa e anexe o arquivo.');
  p.aposEnviar && p.aposEnviar();
}

async function marcarOrcEnviado(o) {
  if (!o?.id || o.status !== 'Rascunho') return;
  try {
    const u = await req('PUT', `/orcamentos/${o.id}`, { cliente_nome: o.cliente_nome, cliente_cnpj: o.cliente_cnpj, cliente_endereco: o.cliente_endereco, obra_descricao: o.obra_descricao, data: o.data, validade: parseInt(o.validade) || 10, status: 'Enviado', obs: o.obs, itens: (o.itens || []).map((it, i) => ({ descricao: it.descricao, und: it.und, qtd: parseFloat(it.qtd) || 0, vunit: parseFloat(it.vunit) || 0, ordem: i })) });
    S.orcamentos = S.orcamentos.map(x => x.id === u.id ? u : x); if (S.orc?.id === u.id) S.orc = u;
    toast('Orçamento marcado como "Enviado"'); renderMain();
  } catch { /* não atrapalha o envio */ }
}

function renderEditorOrc(main) {
  const o = S.orc; const t = totalOrc();
  const linhas = (o.itens || []).map((it, i) => { const vt = (parseFloat(it.qtd) || 0) * (parseFloat(it.vunit) || 0); return `<tr><td class="it-n" style="color:var(--text-muted);text-align:center;font-size:10px">${String(i + 1).padStart(2, '0')}</td><td class="it-desc"><input class="inline-inp" value="${esc(it.descricao)}" oninput="updItem(${i},'descricao',this.value)" /></td><td class="it-und" data-label="Und"><input class="inline-inp inp-sm" value="${esc(it.und)}" oninput="updItem(${i},'und',this.value)" /></td><td class="it-qtd" data-label="Qtd"><input class="inline-inp inp-num" type="number" value="${it.qtd}" oninput="updItem(${i},'qtd',this.value)" /></td><td class="it-vu" data-label="Vl unit"><input class="inline-inp inp-num" type="number" step="0.01" value="${it.vunit}" oninput="updItem(${i},'vunit',this.value)" /></td><td class="it-tot" style="text-align:right"><span class="chip" id="chip-${i}">R$ ${fmtBR(vt)}</span></td><td class="it-rem"><button class="btn-rem" onclick="delItem(${i})" aria-label="Remover item"><i class="ti ti-trash" aria-hidden="true"></i></button></td></tr>`; }).join('');
  main.innerHTML = `
    <div class="editor-topbar editor-topbar-orc">
      <button class="btn-voltar" onclick="fecharOrc()"><i class="ti ti-arrow-left" aria-hidden="true"></i> Orçamentos</button>
      <div class="et-info" style="flex:1;min-width:0"><div class="editor-titulo">${esc(o.cliente_nome || 'Novo orçamento')}</div><div style="font-size:11px;color:var(--text-muted)">${esc(o.numero || '')} · ${fmtData(o.data)}</div></div>
      <div class="et-acoes" style="display:flex;gap:7px">
        <button class="btn btn-whats" onclick="pdfOrc(${o.id})"><i class="ti ti-brand-whatsapp" aria-hidden="true"></i> PDF / Enviar</button>
        <button class="btn btn-p" onclick="salvarOrc()"><i class="ti ti-device-floppy" aria-hidden="true"></i> Salvar</button>
      </div>
    </div>
    <div class="total-fixo"><span style="font-size:11px;color:rgba(255,255,255,.6)">${(o.itens || []).length} itens · Total</span><span class="total-fixo-valor">R$ ${fmtBR(t)}</span></div>
    <div class="editor-scroll">
      <div class="card">
        <div class="card-title" style="margin-bottom:14px">Dados do cliente</div>
        <div class="form-grid2">
          <div class="field col-full"><label>Nome / Razão social</label><input value="${esc(o.cliente_nome)}" oninput="updOrcCliente('cliente_nome',this.value)" placeholder="Ex: Prefeitura de Amontada" /></div>
          <div class="field"><label>CNPJ / CPF</label><input value="${esc(o.cliente_cnpj)}" oninput="updOrcCliente('cliente_cnpj',this.value)" placeholder="00.000.000/0001-00" /></div>
          <div class="field"><label>Data</label><input type="date" value="${o.data || ''}" oninput="updOrcCampo('data',this.value)" /></div>
          <div class="field col-full"><label>Endereço</label><input value="${esc(o.cliente_endereco)}" oninput="updOrcCliente('cliente_endereco',this.value)" /></div>
          <div class="field col-full"><label>Objeto / Obra</label><input value="${esc(o.obra_descricao)}" oninput="updOrcCliente('obra_descricao',this.value)" /></div>
          <div class="field"><label>Válido (dias)</label><input type="number" value="${o.validade || 10}" oninput="updOrcCampo('validade',this.value)" style="width:90px" /></div>
          <div class="field"><label>Status</label><select onchange="updOrcCampo('status',this.value)">${['Rascunho','Enviado','Aprovado','Reprovado'].map(s => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select></div>
        </div>
      </div>
      <div class="card">
        <div class="card-title" style="margin-bottom:14px">Itens do orçamento</div>
        <div style="overflow-x:auto"><table class="itens-table">
          <thead><tr><th style="width:30px">Nº</th><th>Descrição</th><th style="width:60px;text-align:right">UND</th><th style="width:60px;text-align:right">Qtd</th><th style="width:90px;text-align:right">Vl unit</th><th style="width:100px;text-align:right">Vl total</th><th style="width:30px"></th></tr></thead>
          <tbody>${linhas}<tr class="it-novo" style="background:#ebf4ff;border-top:1.5px dashed #90c2f7"><td class="it-n" style="color:var(--text-muted);text-align:center;font-size:10px">+</td><td class="it-desc"><input class="inline-inp" id="n-desc" placeholder="Nova descrição..." /></td><td class="it-und" data-label="Und"><input class="inline-inp inp-sm" id="n-und" value="UND" /></td><td class="it-qtd" data-label="Qtd"><input class="inline-inp inp-num" id="n-qtd" type="number" placeholder="0" oninput="prevItem()" /></td><td class="it-vu" data-label="Vl unit"><input class="inline-inp inp-num" id="n-vunit" type="number" step="0.01" placeholder="0,00" oninput="prevItem()" /></td><td class="it-tot"></td><td class="it-rem"><button class="btn-add-item" onclick="addItem()" aria-label="Adicionar item">+</button></td></tr></tbody>
        </table></div>
        <div id="preview-bar"></div>
        <div class="total-bar"><span class="tl">Valor total</span><span class="tv">R$ ${fmtBR(t)}</span></div>
      </div>
      <div class="card"><div class="card-title" style="margin-bottom:10px">Observações</div><div class="field"><textarea oninput="updOrcCampo('obs',this.value)" placeholder="Ex: Prazo de execução: 30 dias.">${esc(o.obs)}</textarea></div></div>
      <div class="orc-rodape" style="display:flex;gap:8px;justify-content:flex-end;margin-bottom:32px">
        <button class="btn" onclick="delOrc(${o.id})" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i> Excluir</button>
        <button class="btn" onclick="dupOrc(${o.id})"><i class="ti ti-copy" aria-hidden="true"></i> Duplicar</button>
        <button class="btn btn-p" onclick="salvarOrc()"><i class="ti ti-device-floppy" aria-hidden="true"></i> Salvar</button>
      </div>
    </div>`;
  document.getElementById('n-desc')?.addEventListener('keydown', e => { if (e.key === 'Enter') addItem(); });
}

// ── FINANCEIRO (adiantamentos, adicionais, descontos, empréstimos) ──
const MESES = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
const TIPO_LANC = {
  adiantamento: { rot: 'Adiantamento', badge: 'b-a', sinal: '−' },
  desconto:     { rot: 'Desconto',     badge: 'b-r', sinal: '−' },
  adicional:    { rot: 'Adicional',    badge: 'b-g', sinal: '+' },
};
if (!S.finAno) { const h = new Date(); S.finAno = h.getFullYear(); S.finMes = h.getMonth() + 1; }

function seletorMes(onchange) {
  const anos = []; for (let a = new Date().getFullYear() + 1; a >= 2025; a--) anos.push(a);
  return `<div style="display:flex;gap:6px;align-items:center">
    <button class="btn" onclick="mudarMes(-1, '${onchange}')" aria-label="Mês anterior"><i class="ti ti-chevron-left" aria-hidden="true"></i></button>
    <select class="inp-sm" style="width:auto;min-width:130px" onchange="S.finMes=+this.value;${onchange}()">${MESES.map((m, i) => `<option value="${i + 1}" ${S.finMes === i + 1 ? 'selected' : ''}>${m}</option>`).join('')}</select>
    <select class="inp-sm" style="width:auto;min-width:80px" onchange="S.finAno=+this.value;${onchange}()">${anos.map(a => `<option ${S.finAno === a ? 'selected' : ''}>${a}</option>`).join('')}</select>
    <button class="btn" onclick="mudarMes(1, '${onchange}')" aria-label="Próximo mês"><i class="ti ti-chevron-right" aria-hidden="true"></i></button>
  </div>`;
}
function mudarMes(delta, fn) {
  let m = S.finMes + delta, a = S.finAno;
  if (m < 1) { m = 12; a--; } if (m > 12) { m = 1; a++; }
  S.finMes = m; S.finAno = a; window[fn]();
}
function opcoesFuncionarios(sel) {
  return S.eletricistas.map(e => `<option value="${e.id}" ${e.id === sel ? 'selected' : ''}>${esc(e.nome)}</option>`).join('');
}

async function carregarFinanceiro() {
  const main = document.getElementById('main');
  if (S.tela !== 'financeiro' || !main) return;
  main.innerHTML = '<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>';
  try {
    const [lancs, emps] = await Promise.all([
      req('GET', `/financeiro/lancamentos?ano=${S.finAno}&mes=${S.finMes}`),
      req('GET', '/financeiro/emprestimos'),
    ]);
    S.lancs = lancs || []; S.emps = emps || [];
    renderFinanceiro(main);
  } catch (err) { main.innerHTML = `<div class="content"><p class="empty">${esc(err.message)}</p></div>`; }
}

function renderFinanceiro(main) {
  const tot = t => S.lancs.filter(l => l.tipo === t).reduce((a, l) => a + l.valor, 0);
  const linhas = S.lancs.map(l => {
    const t = TIPO_LANC[l.tipo] || { rot: l.tipo, badge: '', sinal: '' };
    return `<tr>
      <td>${fmtData(l.data)}</td>
      <td style="font-weight:500;color:var(--text-primary)">${esc(l.eletricista_nome)}</td>
      <td><span class="badge ${t.badge}">${t.rot}</span></td>
      <td style="color:var(--text-muted)">${esc(l.descricao || '')}</td>
      <td style="font-weight:500;text-align:right;white-space:nowrap">${t.sinal} R$ ${fmtBR(l.valor)}</td>
      <td><div style="display:flex;gap:4px;justify-content:flex-end">
        <button class="btn" onclick="abrirModalLanc(${l.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
        <button class="btn" onclick="excluirLanc(${l.id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
      </div></td></tr>`;
  }).join('');

  const emps = S.emps.map(e => {
    const pct = Math.min(100, Math.round(e.pago_ate_hoje / e.valor_total * 100));
    const ini = new Date(e.inicio + 'T12:00:00');
    return `<div class="obra-item emp-item">
      <div class="obra-dot" style="background:${e.quitado ? '#10b981' : '#f59e0b'}"></div>
      <div class="obra-info">
        <div class="obra-nome">${esc(e.eletricista_nome)} · ${esc(e.descricao)}</div>
        <div class="obra-loc">R$ ${fmtBR(e.valor_parcela)}/mês desde ${MESES[ini.getMonth()].toLowerCase()}/${ini.getFullYear()} · total R$ ${fmtBR(e.valor_total)}</div>
        <div class="prog"><div class="prog-fill" style="width:${pct}%;background:${e.quitado ? '#10b981' : '#f59e0b'}"></div></div>
      </div>
      <div class="obra-saldo">
        <div class="obra-val" style="color:${e.quitado ? '#15803d' : '#a16207'}">${e.quitado ? 'Quitado' : 'Falta R$ ' + fmtBR(e.restante)}</div>
        <div class="obra-pct">${e.quitado ? '' : e.parcelas_restantes + ' parcela(s)'}</div>
      </div>
      <div class="emp-acoes" style="display:flex;gap:4px;margin-left:8px">
        <button class="btn" onclick="abrirModalEmp(${e.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
        <button class="btn" onclick="excluirEmp(${e.id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
      </div>
    </div>`;
  }).join('') || '<p class="empty">Nenhum empréstimo cadastrado</p>';

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Financeiro da equipe</div><div class="topbar-sub">Adiantamentos, adicionais, descontos e empréstimos</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" onclick="abrirModalEmp()"><i class="ti ti-moneybag" aria-hidden="true"></i> Novo empréstimo</button>
        <button class="btn btn-p" onclick="abrirModalLanc()"><i class="ti ti-plus" aria-hidden="true"></i> Novo lançamento</button>
      </div>
    </div>
    <div class="content">
      <div style="margin-bottom:14px">${seletorMes('carregarFinanceiro')}</div>
      <div class="metrics">
        <div class="metric"><div class="metric-ico amber"><i class="ti ti-cash" aria-hidden="true"></i></div><div class="metric-label">Adiantamentos</div><div class="metric-val">R$ ${fmtBR(tot('adiantamento'))}</div><div class="metric-sub">${MESES[S.finMes - 1]}/${S.finAno}</div></div>
        <div class="metric"><div class="metric-ico green"><i class="ti ti-plus" aria-hidden="true"></i></div><div class="metric-label">Adicionais</div><div class="metric-val">R$ ${fmtBR(tot('adicional'))}</div><div class="metric-sub">pagos a mais no mês</div></div>
        <div class="metric"><div class="metric-ico red"><i class="ti ti-minus" aria-hidden="true"></i></div><div class="metric-label">Descontos</div><div class="metric-val">R$ ${fmtBR(tot('desconto'))}</div><div class="metric-sub">avulsos no mês</div></div>
        <div class="metric"><div class="metric-ico blue"><i class="ti ti-moneybag" aria-hidden="true"></i></div><div class="metric-label">Empréstimos em aberto</div><div class="metric-val">R$ ${fmtBR(S.emps.reduce((a, e) => a + e.restante, 0))}</div><div class="metric-sub">${S.emps.filter(e => !e.quitado).length} ativo(s)</div></div>
      </div>
      <div class="table-card" style="margin-bottom:16px">
        <table class="tbl-cards">
          <thead><tr><th>Data</th><th>Funcionário</th><th>Tipo</th><th>Descrição</th><th style="text-align:right">Valor</th><th></th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="6" class="empty">Nenhum lançamento neste mês</td></tr>'}</tbody>
        </table>
      </div>
      <div class="card">
        <div class="card-header"><span class="card-title"><i class="ti ti-moneybag" aria-hidden="true"></i> Empréstimos parcelados (descontados todo mês na folha)</span></div>
        ${emps}
      </div>
    </div>`;
}

function abrirModalLanc(id) {
  const l = id ? S.lancs.find(x => x.id === id) : null;
  const hoje = new Date();
  const dataPadrao = (S.finAno === hoje.getFullYear() && S.finMes === hoje.getMonth() + 1)
    ? hoje.toISOString().slice(0, 10)
    : `${S.finAno}-${String(S.finMes).padStart(2, '0')}-01`;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${l ? 'Editar lançamento' : 'Novo lançamento'}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="field"><label>Funcionário *</label><select id="ml-elet">${opcoesFuncionarios(l?.eletricista_id)}</select></div>
        <div class="form-grid2">
          <div class="field"><label>Tipo *</label>
            <select id="ml-tipo">${Object.entries(TIPO_LANC).map(([k, t]) => `<option value="${k}" ${l?.tipo === k ? 'selected' : ''}>${t.rot} (${t.sinal})</option>`).join('')}</select>
          </div>
          <div class="field"><label>Valor (R$) *</label><input id="ml-valor" type="number" step="0.01" value="${l?.valor || ''}" placeholder="0,00" /></div>
        </div>
        <div class="field"><label>Data * <span style="font-weight:400;color:var(--text-muted)">(o mês desta data define a folha)</span></label><input id="ml-data" type="date" value="${l?.data || dataPadrao}" /></div>
        <div class="field"><label>Descrição</label><input id="ml-desc" value="${esc(l?.descricao || '')}" placeholder="Ex: Vale, Pix adiantado, gratificação..." /></div>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarLanc(${l?.id || 'null'})">${l ? 'Salvar' : 'Lançar'}</button>
        </div>
      </div>
    </div>`;
}

async function salvarLanc(id) {
  const data = {
    eletricista_id: +document.getElementById('ml-elet').value,
    tipo: document.getElementById('ml-tipo').value,
    valor: parseFloat(document.getElementById('ml-valor').value) || 0,
    data: document.getElementById('ml-data').value,
    descricao: document.getElementById('ml-desc').value.trim() || null,
  };
  if (!data.eletricista_id || !data.valor || !data.data) { toast('Preencha funcionário, valor e data', 'erro'); return; }
  try {
    await req(id ? 'PUT' : 'POST', id ? `/financeiro/lancamentos/${id}` : '/financeiro/lancamentos', data);
    fecharModal(); toast(id ? 'Lançamento atualizado!' : 'Lançamento salvo!');
    const d = new Date(data.data + 'T12:00:00'); S.finAno = d.getFullYear(); S.finMes = d.getMonth() + 1;
    carregarFinanceiro();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirLanc(id) {
  if (!confirm('Excluir este lançamento?')) return;
  try { await req('DELETE', `/financeiro/lancamentos/${id}`); toast('Excluído!'); carregarFinanceiro(); }
  catch (err) { toast(err.message, 'erro'); }
}

function abrirModalEmp(id) {
  const e = id ? S.emps.find(x => x.id === id) : null;
  const mesPadrao = e ? e.inicio.slice(0, 7) : `${S.finAno}-${String(S.finMes).padStart(2, '0')}`;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${e ? 'Editar empréstimo' : 'Novo empréstimo'}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="field"><label>Funcionário *</label><select id="mp-elet">${opcoesFuncionarios(e?.eletricista_id)}</select></div>
        <div class="field"><label>Descrição *</label><input id="mp-desc" value="${esc(e?.descricao || '')}" placeholder="Ex: Moto, Empréstimo pessoal" /></div>
        <div class="form-grid2">
          <div class="field"><label>Valor total (R$) *</label><input id="mp-total" type="number" step="0.01" value="${e?.valor_total || ''}" placeholder="5.000,00" /></div>
          <div class="field"><label>Parcela por mês (R$) *</label><input id="mp-parcela" type="number" step="0.01" value="${e?.valor_parcela || ''}" placeholder="500,00" /></div>
        </div>
        <div class="field"><label>Primeira parcela na folha de *</label><input id="mp-inicio" type="month" value="${mesPadrao}" /></div>
        <div class="field"><label>Observação</label><input id="mp-obs" value="${esc(e?.observacao || '')}" /></div>
        <p style="font-size:12px;color:var(--text-muted);margin:4px 0 0">A parcela é descontada automaticamente na folha de cada mês até completar o valor total.</p>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarEmp(${e?.id || 'null'})">${e ? 'Salvar' : 'Cadastrar'}</button>
        </div>
      </div>
    </div>`;
}

async function salvarEmp(id) {
  const ini = document.getElementById('mp-inicio').value;
  const data = {
    eletricista_id: +document.getElementById('mp-elet').value,
    descricao: document.getElementById('mp-desc').value.trim(),
    valor_total: parseFloat(document.getElementById('mp-total').value) || 0,
    valor_parcela: parseFloat(document.getElementById('mp-parcela').value) || 0,
    inicio: ini ? ini + '-01' : '',
    observacao: document.getElementById('mp-obs').value.trim() || null,
  };
  if (!data.eletricista_id || !data.descricao || !data.valor_total || !data.valor_parcela || !data.inicio) { toast('Preencha todos os campos com *', 'erro'); return; }
  try {
    await req(id ? 'PUT' : 'POST', id ? `/financeiro/emprestimos/${id}` : '/financeiro/emprestimos', data);
    fecharModal(); toast(id ? 'Empréstimo atualizado!' : 'Empréstimo cadastrado!'); carregarFinanceiro();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirEmp(id) {
  if (!confirm('Excluir este empréstimo? As parcelas deixam de ser descontadas em todas as folhas.')) return;
  try { await req('DELETE', `/financeiro/emprestimos/${id}`); toast('Excluído!'); carregarFinanceiro(); }
  catch (err) { toast(err.message, 'erro'); }
}

// ── FOLHA MENSAL ──────────────────────────────────────────────
async function carregarFolha() {
  const main = document.getElementById('main');
  if (S.tela !== 'folha' || !main) return;
  main.innerHTML = '<div class="loading"><div class="spinner"></div><p>Calculando folha...</p></div>';
  try {
    const [f, st] = await Promise.all([
      req('GET', `/financeiro/folha?ano=${S.finAno}&mes=${S.finMes}`),
      req('GET', `/comprovantes/status?ano=${S.finAno}&mes=${S.finMes}`).catch(() => ({})),
    ]);
    S.folha = f; S.folhaPagos = st || {};
    renderFolha(main);
  } catch (err) { main.innerHTML = `<div class="content"><p class="empty">${esc(err.message)}</p></div>`; }
}

function renderFolha(main) {
  const f = S.folha || { linhas: [], totais: {} };
  const t = f.totais || {};
  const neg = v => v ? `<span style="color:#b91c1c">− ${fmtBR(v)}</span>` : '<span style="color:var(--text-muted)">—</span>';
  const linhas = f.linhas.map(l => `
    <tr>
      <td class="td-titulo link-cal" onclick="abrirCalendario(${l.eletricista_id})" title="Ver dias trabalhados"><div style="font-weight:500;color:var(--text-primary)">${esc(l.nome)} <i class="ti ti-calendar-event" aria-hidden="true" style="color:#9aa5b4;font-size:13px"></i>${(S.folhaPagos || {})[l.eletricista_id] ? ' <span class="badge b-g" title="Comprovante anexado"><i class="ti ti-check" aria-hidden="true"></i> pago</span>' : ''}</div>
        <div style="font-size:11px;color:var(--text-muted)">${l.tipo_contrato === 'Mensalista' ? 'Mensalista' : l.dias + ' dia(s) apontado(s)'}</div></td>
      <td data-label="${l.tipo_contrato === 'Mensalista' ? 'Fixo' : 'Diárias'}" style="text-align:right">${l.tipo_contrato === 'Mensalista' ? fmtBR(l.salario_fixo) + ' <span class="badge" style="font-size:10px">fixo</span>' : fmtBR(l.valor_diarias)}</td>
      <td data-label="Adicionais" class="${l.adicionais ? '' : 'td-vazio'}" style="text-align:right">${l.adicionais ? '+ ' + fmtBR(l.adicionais) : '<span style="color:var(--text-muted)">—</span>'}</td>
      <td data-label="Bruto" style="text-align:right;font-weight:500">${fmtBR(l.bruto)}</td>
      <td data-label="Adiantamentos" class="${l.adiantamentos ? '' : 'td-vazio'}" style="text-align:right">${neg(l.adiantamentos)}</td>
      <td data-label="Descontos" class="${l.descontos ? '' : 'td-vazio'}" style="text-align:right">${neg(l.descontos)}</td>
      <td data-label="Parcelas${l.parcelas_detalhe.length ? ' (' + esc(l.parcelas_detalhe.map(x => x.split(':')[0]).join(', ')) + ')' : ''}" class="${l.parcelas ? '' : 'td-vazio'}" style="text-align:right" title="${esc(l.parcelas_detalhe.join(' | '))}">${neg(l.parcelas)}</td>
      <td data-label="A receber" class="td-destaque" style="text-align:right;font-weight:600;color:${l.a_receber < 0 ? '#b91c1c' : 'var(--text-primary)'}">R$ ${fmtBR(l.a_receber)}</td>
    </tr>`).join('');

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Folha mensal</div><div class="topbar-sub">${MESES[S.finMes - 1]} de ${S.finAno} · ${f.linhas.length} funcionário(s)</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" onclick="navegar('financeiro')"><i class="ti ti-cash" aria-hidden="true"></i> Lançar adiantamento</button>
        <button class="btn btn-whats" onclick="pdfFolha()"><i class="ti ti-brand-whatsapp" aria-hidden="true"></i> PDF / Enviar</button>
      </div>
    </div>
    <div class="content">
      <div style="margin-bottom:14px">${seletorMes('carregarFolha')}</div>
      <div class="metrics">
        <div class="metric"><div class="metric-ico blue"><i class="ti ti-report-money" aria-hidden="true"></i></div><div class="metric-label">Total bruto</div><div class="metric-val">R$ ${fmtBR(t.bruto)}</div><div class="metric-sub">diárias + fixos + adicionais</div></div>
        <div class="metric"><div class="metric-ico amber"><i class="ti ti-cash" aria-hidden="true"></i></div><div class="metric-label">Adiantamentos</div><div class="metric-val">R$ ${fmtBR(t.adiantamentos)}</div><div class="metric-sub">já pagos no mês</div></div>
        <div class="metric"><div class="metric-ico red"><i class="ti ti-moneybag" aria-hidden="true"></i></div><div class="metric-label">Descontos + parcelas</div><div class="metric-val">R$ ${fmtBR((t.descontos || 0) + (t.parcelas || 0))}</div><div class="metric-sub">empréstimos e avulsos</div></div>
        <div class="metric"><div class="metric-ico green"><i class="ti ti-wallet" aria-hidden="true"></i></div><div class="metric-label">A pagar</div><div class="metric-val" style="color:#15803d">R$ ${fmtBR(t.a_receber)}</div><div class="metric-sub">valor final a receber</div></div>
      </div>
      <div class="table-card" style="overflow-x:auto">
        <table class="tbl-lista">
          <thead><tr><th>Funcionário</th><th style="text-align:right">Diárias / Fixo</th><th style="text-align:right">Adicionais</th><th style="text-align:right">Bruto</th><th style="text-align:right">Adiant.</th><th style="text-align:right">Descontos</th><th style="text-align:right">Parcelas</th><th style="text-align:right">A receber</th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="8" class="empty">Nenhum movimento neste mês</td></tr>'}</tbody>
          ${f.linhas.length ? `<tfoot><tr style="font-weight:600;border-top:2px solid var(--border, #e5e7eb)">
            <td class="td-titulo">TOTAL DA FOLHA</td><td data-label="Diárias + fixos" style="text-align:right">${fmtBR((t.valor_diarias || 0) + (t.salario_fixo || 0))}</td><td data-label="Adicionais" style="text-align:right">${fmtBR(t.adicionais)}</td>
            <td data-label="Bruto" style="text-align:right">${fmtBR(t.bruto)}</td><td data-label="Adiantamentos" style="text-align:right">${fmtBR(t.adiantamentos)}</td><td data-label="Descontos" style="text-align:right">${fmtBR(t.descontos)}</td>
            <td data-label="Parcelas" style="text-align:right">${fmtBR(t.parcelas)}</td><td data-label="A receber" class="td-destaque" style="text-align:right">R$ ${fmtBR(t.a_receber)}</td></tr></tfoot>` : ''}
        </table>
      </div>
      <p style="font-size:12px;color:var(--text-muted);margin-top:10px">Mensalistas recebem só o fixo + adicionais (diárias lançadas para eles servem apenas para o custo das obras). Passe o mouse em "Parcelas" para ver o detalhe dos empréstimos.</p>
    </div>`;
}

async function pdfFolha() {
  const ano = S.finAno, mes = S.finMes;
  document.getElementById('modal-root').innerHTML = `<div class="modal-overlay"><div class="modal" style="max-width:380px;text-align:center"><div class="spinner" style="margin:10px auto"></div><p style="font-size:13px;color:var(--text-muted)">Gerando o PDF da folha...</p></div></div>`;
  try {
    const { blob } = await reqArquivo(`/financeiro/folha/pdf?ano=${ano}&mes=${mes}`);
    const arq = new File([blob], `Folha_AZ_${MESES[mes - 1]}_${ano}.pdf`, { type: 'application/pdf' });
    const t = (S.folha && S.folha.ano === ano && S.folha.mes === mes) ? S.folha.totais || {} : {};
    modalPdfPronto(arq, `${MESES[mes - 1]} de ${ano}${t.a_receber != null ? ' · a pagar R$ ' + fmtBR(t.a_receber) : ''}`, null,
      `Folha de pagamento AZ Elétrica — ${MESES[mes - 1]}/${ano}.`);
  } catch (err) { fecharModal(); toast(err.message, 'erro'); }
}

// ── DESPESAS (alimentação e outros custos) ─────────────────────
const CAT_DESP = {
  alimentacao: { nome: 'Alimentação', badge: 'b-a', ico: 'ti-tools-kitchen-2' },
  combustivel: { nome: 'Combustível / Frete', badge: '', ico: 'ti-gas-station' },
  ferramentas: { nome: 'Ferramentas / EPI', badge: '', ico: 'ti-tool' },
  hospedagem:  { nome: 'Hospedagem / Deslocamento', badge: '', ico: 'ti-bed' },
  outros:      { nome: 'Outros', badge: '', ico: 'ti-dots' },
};

async function carregarDespesas() {
  const main = document.getElementById('main');
  if (S.tela !== 'despesas' || !main) return;
  main.innerHTML = '<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>';
  try { S.desp = await req('GET', `/despesas/?ano=${S.finAno}&mes=${S.finMes}`); renderDespesas(main); }
  catch (err) { main.innerHTML = `<div class="content"><p class="empty">${esc(err.message)}</p></div>`; }
}

function valorPessoaPadrao() {
  const a = (S.desp?.despesas || []).find(d => d.categoria === 'alimentacao' && d.automatica && d.pessoas);
  if (a) return +(a.valor / a.pessoas).toFixed(2);
  try { return +localStorage.getItem('az_valor_refeicao') || 20; } catch { return 20; }
}

function renderDespesas(main) {
  const D = S.desp || { despesas: [], por_categoria: [], total: 0, alimentacao: {} };
  const al = D.alimentacao || {};
  const outros = D.por_categoria.filter(c => c.id !== 'alimentacao').reduce((a, c) => a + c.valor, 0);
  const linhas = D.despesas.map(d => {
    const c = CAT_DESP[d.categoria] || { nome: d.categoria, badge: '' };
    return `<tr>
      <td>${fmtData(d.data)}</td>
      <td><span class="badge ${c.badge}">${c.nome}</span>${d.automatica ? ' <span style="font-size:10px;color:var(--text-muted)" title="Calculada pelos apontamentos">auto</span>' : ''}</td>
      <td style="color:var(--text-muted)">${esc(d.descricao || '')}${d.obra_nome ? ' · ' + esc(d.obra_nome) : ''}</td>
      <td style="text-align:right;font-weight:500;white-space:nowrap">R$ ${fmtBR(d.valor)}</td>
      <td><div style="display:flex;gap:4px;justify-content:flex-end">
        <button class="btn" onclick="abrirModalDesp(${d.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
        <button class="btn" onclick="excluirDesp(${d.id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
      </div></td></tr>`;
  }).join('');
  const resumoCat = D.por_categoria.filter(c => c.valor).map(c => `
    <div class="fin-row" style="display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border, #eef0f3)">
      <span class="fin-label">${(CAT_DESP[c.id] || {}).nome || c.nome}</span><span class="fin-val" style="font-weight:500">R$ ${fmtBR(c.valor)}</span></div>`).join('')
    || '<p class="empty">Nenhuma despesa neste mês</p>';

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Despesas</div><div class="topbar-sub">Alimentação e outros custos · ${MESES[S.finMes - 1]} de ${S.finAno}</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn" onclick="abrirModalCalcAlim()"><i class="ti ti-calculator" aria-hidden="true"></i> Calcular alimentação</button>
        <button class="btn btn-p" onclick="abrirModalDesp()"><i class="ti ti-plus" aria-hidden="true"></i> Nova despesa</button>
      </div>
    </div>
    <div class="content">
      <div style="margin-bottom:14px">${seletorMes('carregarDespesas')}</div>
      <div class="metrics">
        <div class="metric"><div class="metric-ico amber"><i class="ti ti-tools-kitchen-2" aria-hidden="true"></i></div><div class="metric-label">Alimentação</div><div class="metric-val">R$ ${fmtBR(al.total)}</div><div class="metric-sub">${al.refeicoes || 0} refeições em ${al.dias || 0} dia(s)</div></div>
        <div class="metric"><div class="metric-ico blue"><i class="ti ti-users" aria-hidden="true"></i></div><div class="metric-label">Média de pessoas/dia</div><div class="metric-val">${al.dias ? (al.refeicoes / al.dias).toFixed(1) : '0'}</div><div class="metric-sub">nos dias com refeição</div></div>
        <div class="metric"><div class="metric-ico red"><i class="ti ti-receipt" aria-hidden="true"></i></div><div class="metric-label">Outros custos</div><div class="metric-val">R$ ${fmtBR(outros)}</div><div class="metric-sub">combustível, ferramentas, hospedagem...</div></div>
        <div class="metric"><div class="metric-ico green"><i class="ti ti-sum" aria-hidden="true"></i></div><div class="metric-label">Total de despesas</div><div class="metric-val">R$ ${fmtBR(D.total)}</div><div class="metric-sub">sem contar a mão de obra</div></div>
      </div>
      <div class="row2">
        <div class="table-card" style="overflow-x:auto">
          <table class="tbl-cards">
            <thead><tr><th>Data</th><th>Categoria</th><th>Descrição</th><th style="text-align:right">Valor</th><th></th></tr></thead>
            <tbody>${linhas || '<tr><td colspan="5" class="empty">Nenhuma despesa neste mês. Use "Calcular alimentação" para gerar pelos apontamentos.</td></tr>'}</tbody>
          </table>
        </div>
        <div class="card" style="align-self:start">
          <div class="card-header"><span class="card-title"><i class="ti ti-chart-pie" aria-hidden="true"></i> Por categoria</span></div>
          ${resumoCat}
        </div>
      </div>
    </div>`;
}

function abrirModalCalcAlim() {
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">Calcular alimentação · ${MESES[S.finMes - 1]}/${S.finAno}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <p style="font-size:13px;color:var(--text-muted);margin:0 0 12px">Para cada dia com apontamento, conta quem trabalhou e multiplica pelo valor por pessoa. Dias que você lançou ou editou à mão não são alterados.</p>
        <div class="field"><label>Valor por pessoa/dia (R$)</label><input id="ca-valor" type="number" step="0.01" value="${valorPessoaPadrao()}" /></div>
        <label style="display:flex;gap:8px;align-items:center;font-size:13px;margin:6px 0 4px"><input id="ca-mens" type="checkbox" checked style="width:auto" /> Incluir mensalistas em todo dia com equipe trabalhando</label>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="calcularAlimentacao()">Calcular</button>
        </div>
      </div>
    </div>`;
}

async function calcularAlimentacao() {
  const valor = parseFloat(document.getElementById('ca-valor').value) || 0;
  if (valor <= 0) { toast('Informe o valor por pessoa', 'erro'); return; }
  try {
    const r = await req('POST', '/despesas/alimentacao/calcular', { ano: S.finAno, mes: S.finMes, valor_pessoa: valor, incluir_mensalistas: document.getElementById('ca-mens').checked });
    try { localStorage.setItem('az_valor_refeicao', valor); } catch {}
    fecharModal(); toast(`Alimentação calculada: ${r.dias} dia(s), R$ ${fmtBR(r.total)}`); carregarDespesas();
  } catch (err) { toast(err.message, 'erro'); }
}

function abrirModalDesp(id) {
  const d = id ? (S.desp?.despesas || []).find(x => x.id === id) : null;
  const hoje = new Date();
  const dataPadrao = (S.finAno === hoje.getFullYear() && S.finMes === hoje.getMonth() + 1) ? hoje.toISOString().slice(0, 10) : `${S.finAno}-${String(S.finMes).padStart(2, '0')}-01`;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${d ? 'Editar despesa' : 'Nova despesa'}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="form-grid2">
          <div class="field"><label>Categoria *</label><select id="md-cat">${Object.entries(CAT_DESP).map(([k, c]) => `<option value="${k}" ${d?.categoria === k ? 'selected' : ''}>${c.nome}</option>`).join('')}</select></div>
          <div class="field"><label>Valor (R$) *</label><input id="md-valor" type="number" step="0.01" value="${d?.valor || ''}" placeholder="0,00" /></div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Data *</label><input id="md-data" type="date" value="${d?.data || dataPadrao}" /></div>
          <div class="field"><label>Pessoas <span style="font-weight:400;color:var(--text-muted)">(alimentação)</span></label><input id="md-pessoas" type="number" value="${d?.pessoas || ''}" /></div>
        </div>
        <div class="field"><label>Obra <span style="font-weight:400;color:var(--text-muted)">(opcional)</span></label><select id="md-obra"><option value="">—</option>${S.obras.map(o => `<option value="${o.id}" ${d?.obra_id === o.id ? 'selected' : ''}>${esc(o.nome)}</option>`).join('')}</select></div>
        <div class="field"><label>Descrição</label><input id="md-desc" value="${esc(d?.descricao || '')}" placeholder="Ex: Rancho Atacadão, diesel caminhonete..." /></div>
        ${d?.automatica ? '<p style="font-size:12px;color:var(--text-muted);margin:0">Ao salvar, este dia passa a ser manual e o cálculo automático não mexe mais nele.</p>' : ''}
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarDesp(${d?.id || 'null'})">${d ? 'Salvar' : 'Lançar'}</button>
        </div>
      </div>
    </div>`;
}

async function salvarDesp(id) {
  const data = {
    categoria: document.getElementById('md-cat').value,
    valor: parseFloat(document.getElementById('md-valor').value) || 0,
    data: document.getElementById('md-data').value,
    pessoas: parseInt(document.getElementById('md-pessoas').value) || null,
    obra_id: parseInt(document.getElementById('md-obra').value) || null,
    descricao: document.getElementById('md-desc').value.trim() || null,
  };
  if (!data.valor || !data.data) { toast('Preencha valor e data', 'erro'); return; }
  try {
    await req(id ? 'PUT' : 'POST', id ? `/despesas/${id}` : '/despesas/', data);
    const dt = new Date(data.data + 'T12:00:00'); S.finAno = dt.getFullYear(); S.finMes = dt.getMonth() + 1;
    fecharModal(); toast(id ? 'Despesa atualizada!' : 'Despesa lançada!'); carregarDespesas();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirDesp(id) {
  if (!confirm('Excluir esta despesa?')) return;
  try { await req('DELETE', `/despesas/${id}`); toast('Excluída!'); carregarDespesas(); }
  catch (err) { toast(err.message, 'erro'); }
}

// ── FERRAMENTAS (onde está cada unidade) ───────────────────────
async function carregarFerramentas() {
  const main = document.getElementById('main');
  if (S.tela !== 'ferramentas' || !main) return;
  if (!S.ferr) main.innerHTML = '<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>';
  try { S.ferr = await req('GET', '/ferramentas/') || []; renderFerramentas(main); }
  catch (err) { main.innerHTML = `<div class="content"><p class="empty">${esc(err.message)}</p></div>`; }
}

function chipLocal(nome, qtd, cor) {
  return `<span style="display:inline-flex;align-items:center;gap:6px;padding:3px 10px;border-radius:999px;font-size:12px;background:${cor};margin:2px 4px 2px 0;white-space:nowrap">
    ${esc(nome)} <b>${qtd}</b></span>`;
}

function renderFerramentas(main) {
  const filtro = S.ferrFiltro ?? '';          // '' = todas, 'dep' = depósito, id = obra
  const busca = (S.ferrBusca || '').toLowerCase();
  let lista = (S.ferr || []).filter(f => !busca || f.nome.toLowerCase().includes(busca));
  if (filtro === 'dep') lista = lista.filter(f => f.deposito > 0);
  else if (filtro) lista = lista.filter(f => f.locais.some(l => l.obra_id === +filtro));

  const obrasComFerr = {};
  (S.ferr || []).forEach(f => f.locais.forEach(l => { obrasComFerr[l.obra_id] = (obrasComFerr[l.obra_id] || 0) + l.quantidade; }));
  const totalUn = (S.ferr || []).reduce((a, f) => a + f.quantidade_total, 0);
  const emObras = (S.ferr || []).reduce((a, f) => a + f.em_obras, 0);

  const linhas = lista.map(f => {
    const chips = (f.deposito > 0 ? chipLocal('Depósito', f.deposito, '#e5e7eb') : '') +
      f.locais.map(l => chipLocal(l.obra_nome, l.quantidade, (filtro && +filtro === l.obra_id) ? '#fde68a' : '#dbeafe')).join('');
    return `<tr>
      <td><div style="font-weight:500;color:var(--text-primary)">${esc(f.nome)}</div>
        ${f.observacao ? `<div style="font-size:11px;color:var(--text-muted)">${esc(f.observacao)}</div>` : ''}
        ${blocoVisto(f)}</td>
      <td style="text-align:center;font-weight:600">${f.quantidade_total}<span class="so-mobile"> un.</span></td>
      <td>${chips || '<span style="color:var(--text-muted)">—</span>'}</td>
      <td><div style="display:flex;gap:4px;justify-content:flex-end;flex-wrap:wrap">
        <button class="btn btn-visto" onclick="abrirModalVisto(${f.id})" title="Registrar onde viu"><i class="ti ti-map-pin" aria-hidden="true"></i> Vi aqui</button>
        <button class="btn btn-p" onclick="abrirModalMover(${f.id})" title="Mover"><i class="ti ti-arrows-exchange" aria-hidden="true"></i> Mover</button>
        <button class="btn" onclick="abrirHistFerr(${f.id})" title="Histórico"><i class="ti ti-history" aria-hidden="true"></i></button>
        <button class="btn" onclick="abrirModalFerr(${f.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
        <button class="btn" onclick="excluirFerr(${f.id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
      </div></td></tr>`;
  }).join('');

  const opcoesFiltro = `<option value="">Todos os locais</option><option value="dep" ${filtro === 'dep' ? 'selected' : ''}>Depósito</option>` +
    S.obras.filter(o => obrasComFerr[o.id]).sort((a, b) => a.nome.localeCompare(b.nome))
      .map(o => `<option value="${o.id}" ${String(filtro) === String(o.id) ? 'selected' : ''}>${esc(o.nome)} (${obrasComFerr[o.id]})</option>`).join('');

  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Ferramentas</div><div class="topbar-sub">${(S.ferr || []).length} ferramenta(s) · ${totalUn} unidade(s)</div></div>
      <div style="display:flex;gap:8px"><button class="btn btn-p" onclick="abrirModalFerr()"><i class="ti ti-plus" aria-hidden="true"></i> Nova ferramenta</button></div>
    </div>
    <div class="content">
      <div class="metrics">
        <div class="metric"><div class="metric-ico blue"><i class="ti ti-tool" aria-hidden="true"></i></div><div class="metric-label">Unidades</div><div class="metric-val">${totalUn}</div><div class="metric-sub">${(S.ferr || []).length} tipo(s) de ferramenta</div></div>
        <div class="metric"><div class="metric-ico green"><i class="ti ti-building-warehouse" aria-hidden="true"></i></div><div class="metric-label">No depósito</div><div class="metric-val">${totalUn - emObras}</div><div class="metric-sub">disponíveis</div></div>
        <div class="metric"><div class="metric-ico amber"><i class="ti ti-building-factory-2" aria-hidden="true"></i></div><div class="metric-label">Em obras</div><div class="metric-val">${emObras}</div><div class="metric-sub">em ${Object.keys(obrasComFerr).length} obra(s)</div></div>
      </div>
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px">
        <input placeholder="Buscar ferramenta..." value="${esc(S.ferrBusca || '')}" oninput="S.ferrBusca=this.value;renderFerramentas(document.getElementById('main'));this.focus();this.setSelectionRange(this.value.length,this.value.length)" style="flex:1;min-width:180px;padding:8px 12px;border:1px solid var(--border,#d1d5db);border-radius:8px" />
        <select onchange="S.ferrFiltro=this.value;renderFerramentas(document.getElementById('main'))" style="min-width:220px;padding:8px;border:1px solid var(--border,#d1d5db);border-radius:8px">${opcoesFiltro}</select>
      </div>
      <div class="table-card" style="overflow-x:auto">
        <table class="tbl-cards">
          <thead><tr><th>Ferramenta</th><th style="text-align:center">Qtd</th><th>Onde está</th><th></th></tr></thead>
          <tbody>${linhas || `<tr><td colspan="4" class="empty">${(S.ferr || []).length ? 'Nenhuma ferramenta neste filtro' : 'Nenhuma ferramenta cadastrada. Clique em "Nova ferramenta".'}</td></tr>`}</tbody>
        </table>
      </div>
    </div>`;
  carregarFotosVisto(main);
}

// ── Último lugar visto (com foto) ──────────────────────────────
function haQuanto(iso) {
  const d = Math.round((new Date(new Date().toISOString().slice(0, 10) + 'T12:00:00') - new Date(iso + 'T12:00:00')) / 86400000);
  return d <= 0 ? 'hoje' : d === 1 ? 'ontem' : `há ${d} dias`;
}
function blocoVisto(f) {
  const v = f.ultimo_visto;
  if (!v) return `<button class="visto-vazio" onclick="abrirModalVisto(${f.id})"><i class="ti ti-map-pin-plus" aria-hidden="true"></i> Registrar onde foi vista</button>`;
  return `<div class="visto" onclick="abrirHistFerr(${f.id})" title="Ver histórico de onde foi vista">
    ${v.tem_foto ? `<img class="visto-foto" data-visto-foto="${v.id}" alt="Foto" />` : '<span class="visto-foto sem"><i class="ti ti-map-pin" aria-hidden="true"></i></span>'}
    <div class="visto-txt"><div class="visto-rot">Visto por último</div><div class="visto-local">${esc(v.local)}</div>
    <div class="visto-quando">${fmtData(v.data)} · ${haQuanto(v.data)}${v.registrado_por ? ' · ' + esc(v.registrado_por.split(' ').slice(0, 2).join(' ')) : ''}</div></div></div>`;
}
S.fotoVisto = {};
async function urlFotoVisto(vid) {
  if (!S.fotoVisto[vid]) S.fotoVisto[vid] = reqArquivo(`/ferramentas/vistos/${vid}/foto`).then(r => URL.createObjectURL(r.blob)).catch(() => { delete S.fotoVisto[vid]; return ''; });
  return S.fotoVisto[vid];
}
function carregarFotosVisto(raiz) {
  (raiz || document).querySelectorAll('img[data-visto-foto]').forEach(async img => {
    const u = await urlFotoVisto(img.dataset.vistoFoto); if (u) img.src = u;
  });
}
async function verFotoVisto(vid, titulo) {
  const u = await urlFotoVisto(vid); if (!u) { toast('Não foi possível abrir a foto', 'erro'); return; }
  const div = document.createElement('div'); div.className = 'foto-zoom';
  div.innerHTML = `<div class="fz-top"><span>${esc(titulo || '')}</span><button class="btn" aria-label="Fechar"><i class="ti ti-x" aria-hidden="true"></i></button></div><img src="${u}" alt="Foto" />`;
  div.onclick = () => div.remove(); document.body.appendChild(div);
}

function abrirModalVisto(id) {
  const f = S.ferr.find(x => x.id === id);
  const locais = new Set(['Depósito']);
  f.locais.forEach(l => locais.add(l.obra_nome));
  S.obras.filter(o => o.status !== 'Concluída').forEach(o => locais.add(o.nome));
  (S.ferr || []).forEach(x => x.ultimo_visto && locais.add(x.ultimo_visto.local));
  S.vistoFoto = null;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">Onde está · ${esc(f.nome)}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="field"><label>Local onde foi vista *</label>
          <input id="mv-local" list="mv-locais" placeholder="Obra, carro, casa de alguém, depósito..." value="${esc(f.locais.length === 1 && !f.deposito ? f.locais[0].obra_nome : '')}" />
          <datalist id="mv-locais">${[...locais].sort((a, b) => a.localeCompare(b)).map(l => `<option value="${esc(l)}"></option>`).join('')}</datalist></div>
        <div class="form-grid2">
          <div class="field"><label>Data</label><input id="mv-data" type="date" value="${new Date(Date.now() - 3 * 3600e3).toISOString().slice(0, 10)}" /></div>
          <div class="field"><label>Foto</label>
            <label class="btn btn-foto" for="mv-foto"><i class="ti ti-camera" aria-hidden="true"></i> <span id="mv-foto-rot">Tirar / escolher foto</span></label>
            <input id="mv-foto" type="file" accept="image/*" capture="environment" style="display:none" onchange="escolheuFotoVisto(this)" /></div>
        </div>
        <div id="mv-prev"></div>
        <div class="field"><label>Observação</label><input id="mv-obs" placeholder="Ex: no quarto de ferramentas, com o Juan, em cima do andaime..." /></div>
        <p style="font-size:12px;color:var(--text-muted);margin:0">Isto só registra onde a ferramenta foi vista. Para mudar as quantidades por obra, use "Mover".</p>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" id="mv-salvar" onclick="salvarVisto(${f.id})"><i class="ti ti-map-pin" aria-hidden="true"></i> Salvar</button>
        </div>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('mv-local')?.focus(), 50);
}
function escolheuFotoVisto(inp) {
  const f = inp.files?.[0]; if (!f) return;
  S.vistoFoto = f;
  document.getElementById('mv-foto-rot').textContent = 'Trocar foto';
  document.getElementById('mv-prev').innerHTML = `<div class="mv-prev"><img src="${URL.createObjectURL(f)}" alt="Prévia" /><button class="btn" onclick="S.vistoFoto=null;document.getElementById('mv-prev').innerHTML='';document.getElementById('mv-foto-rot').textContent='Tirar / escolher foto'"><i class="ti ti-trash" aria-hidden="true"></i> Remover</button></div>`;
}
async function salvarVisto(id) {
  const local = document.getElementById('mv-local').value.trim();
  if (!local) { toast('Informe onde a ferramenta foi vista', 'erro'); return; }
  const btn = document.getElementById('mv-salvar'); btn.disabled = true; btn.textContent = 'Salvando...';
  try {
    const fd = new FormData();
    fd.append('local', local);
    const obra = S.obras.find(o => o.nome.trim().toLowerCase() === local.toLowerCase()); if (obra) fd.append('obra_id', obra.id);
    const d = document.getElementById('mv-data').value; if (d) fd.append('data', d);
    const o = document.getElementById('mv-obs').value.trim(); if (o) fd.append('observacao', o);
    if (S.vistoFoto) {
      const f = await comprimirImagem(S.vistoFoto, 1280, 0.8);
      if (f.size > 8 * 1024 * 1024) throw new Error('Foto maior que 8 MB');
      fd.append('foto', f, f.name || 'foto.jpg');
    }
    const res = await fetch(API + `/ferramentas/${id}/visto`, { method: 'POST', headers: { Authorization: 'Bearer ' + window._TOKEN }, body: fd });
    if (res.status === 401) { logout(); return; }
    if (!res.ok) { const e = await res.json().catch(() => ({})); throw new Error(e?.detail || 'Erro ' + res.status); }
    S.vistoFoto = null; fecharModal(); toast('Local registrado!'); carregarFerramentas();
  } catch (err) { toast(err.message, 'erro'); btn.disabled = false; btn.innerHTML = '<i class="ti ti-map-pin" aria-hidden="true"></i> Salvar'; }
}
async function excluirVisto(vid, fid) {
  if (!confirm('Excluir este registro de "visto"?')) return;
  try { await req('DELETE', `/ferramentas/vistos/${vid}`); toast('Excluído'); await carregarFerramentas(); abrirHistFerr(fid); }
  catch (err) { toast(err.message, 'erro'); }
}

function abrirModalFerr(id) {
  const f = id ? S.ferr.find(x => x.id === id) : null;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${f ? 'Editar ferramenta' : 'Nova ferramenta'}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="field"><label>Nome *</label><input id="mf-nome" value="${esc(f?.nome || '')}" placeholder="Ex: Escada 7 degraus, Martelete rompedor" /></div>
        <div class="field"><label>Quantidade total *</label><input id="mf-qtd" type="number" min="1" value="${f?.quantidade_total || 1}" /></div>
        <div class="field"><label>Observação</label><input id="mf-obs" value="${esc(f?.observacao || '')}" placeholder="Ex: marca, voltagem, nº de série" /></div>
        ${f ? '' : '<p style="font-size:12px;color:var(--text-muted);margin:0">Ao cadastrar, todas as unidades ficam no Depósito. Depois use "Mover" para mandar para as obras.</p>'}
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarFerr(${f?.id || 'null'})">${f ? 'Salvar' : 'Cadastrar'}</button>
        </div>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('mf-nome')?.focus(), 50);
}

async function salvarFerr(id) {
  const data = { nome: document.getElementById('mf-nome').value.trim(), quantidade_total: parseInt(document.getElementById('mf-qtd').value) || 0, observacao: document.getElementById('mf-obs').value.trim() || null };
  if (!data.nome || data.quantidade_total < 1) { toast('Preencha o nome e a quantidade', 'erro'); return; }
  try {
    await req(id ? 'PUT' : 'POST', id ? `/ferramentas/${id}` : '/ferramentas/', data);
    fecharModal(); toast(id ? 'Ferramenta atualizada!' : 'Ferramenta cadastrada!'); carregarFerramentas();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirFerr(id) {
  const f = S.ferr.find(x => x.id === id);
  if (!confirm(`Excluir "${f?.nome}"? O histórico de movimentações também será apagado.`)) return;
  try { await req('DELETE', `/ferramentas/${id}`); toast('Excluída!'); carregarFerramentas(); }
  catch (err) { toast(err.message, 'erro'); }
}

function abrirModalMover(id) {
  const f = S.ferr.find(x => x.id === id);
  const origens = [];
  if (f.deposito > 0) origens.push({ v: '', n: `Depósito (${f.deposito} disp.)`, q: f.deposito });
  f.locais.forEach(l => origens.push({ v: l.obra_id, n: `${l.obra_nome} (${l.quantidade})`, q: l.quantidade }));
  if (!origens.length) { toast('Nenhuma unidade disponível', 'erro'); return; }
  const obrasOrd = [...S.obras].sort((a, b) => a.nome.localeCompare(b.nome));
  const filtroObra = S.ferrFiltro && S.ferrFiltro !== 'dep' ? +S.ferrFiltro : null;
  // origem padrão: o filtro (se a ferramenta estiver lá) ou o depósito; destino padrão: depósito se vier de obra
  const origemPadrao = filtroObra && f.locais.some(l => l.obra_id === filtroObra) ? filtroObra : origens[0].v;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">Mover · ${esc(f.nome)}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="form-grid2">
          <div class="field"><label>De *</label><select id="mm-de" onchange="ajustarMaxMover()">${origens.map(o => `<option value="${o.v}" data-q="${o.q}" ${String(o.v) === String(origemPadrao) ? 'selected' : ''}>${esc(o.n)}</option>`).join('')}</select></div>
          <div class="field"><label>Para *</label><select id="mm-para"><option value="">Depósito</option>${obrasOrd.map(o => `<option value="${o.id}">${esc(o.nome)}</option>`).join('')}</select></div>
        </div>
        <div class="form-grid2">
          <div class="field"><label>Quantidade *</label><input id="mm-qtd" type="number" min="1" value="1" /></div>
          <div class="field"><label>Data</label><input id="mm-data" type="date" value="${new Date().toISOString().slice(0, 10)}" /></div>
        </div>
        <div class="field"><label>Observação</label><input id="mm-obs" placeholder="Ex: levou o Wesley, voltou com defeito..." /></div>
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="moverFerr(${f.id})"><i class="ti ti-arrows-exchange" aria-hidden="true"></i> Mover</button>
        </div>
      </div>
    </div>`;
  if (origemPadrao === '' && filtroObra) document.getElementById('mm-para').value = filtroObra;   // filtrando uma obra: sugere mandar pra ela
  ajustarMaxMover();
}

function ajustarMaxMover() {
  const de = document.getElementById('mm-de'); const q = +de.selectedOptions[0].dataset.q;
  const inp = document.getElementById('mm-qtd'); inp.max = q; if (+inp.value > q) inp.value = q;
  const para = document.getElementById('mm-para');
  if (de.value && para.value === de.value) para.value = '';          // vindo de obra: sugere voltar ao depósito
  if (!de.value && !para.value) { const op = [...para.options].find(o => o.value); if (op) para.value = op.value; }
}

async function moverFerr(id) {
  const de = document.getElementById('mm-de').value, para = document.getElementById('mm-para').value;
  const body = {
    quantidade: parseInt(document.getElementById('mm-qtd').value) || 0,
    origem_obra_id: de ? +de : null, destino_obra_id: para ? +para : null,
    data: document.getElementById('mm-data').value || null,
    observacao: document.getElementById('mm-obs').value.trim() || null,
  };
  if (body.quantidade < 1) { toast('Informe a quantidade', 'erro'); return; }
  if (de === para) { toast('Origem e destino são o mesmo lugar', 'erro'); return; }
  try { await req('POST', `/ferramentas/${id}/mover`, body); fecharModal(); toast('Ferramenta movida!'); carregarFerramentas(); }
  catch (err) { toast(err.message, 'erro'); }
}

async function abrirHistFerr(id) {
  const f = S.ferr.find(x => x.id === id);
  let hist = [], vistos = [];
  try { [hist, vistos] = await Promise.all([req('GET', `/ferramentas/${id}/historico`), req('GET', `/ferramentas/${id}/vistos`)]); hist = hist || []; vistos = vistos || []; }
  catch (err) { toast(err.message, 'erro'); return; }
  const lv = vistos.map(v => `<div class="visto-item">
      ${v.tem_foto ? `<img class="visto-foto" data-visto-foto="${v.id}" alt="Foto" onclick="verFotoVisto(${v.id}, '${esc((f.nome + ' · ' + v.local).replace(/'/g, ''))}')" />` : '<span class="visto-foto sem"><i class="ti ti-map-pin" aria-hidden="true"></i></span>'}
      <div class="visto-txt" style="flex:1"><div class="visto-local">${esc(v.local)}</div>
        <div class="visto-quando">${fmtData(v.data)} · ${haQuanto(v.data)}${v.registrado_por ? ' · ' + esc(v.registrado_por) : ''}</div>
        ${v.observacao ? `<div class="visto-quando" style="color:#334155">${esc(v.observacao)}</div>` : ''}</div>
      <button class="btn" onclick="excluirVisto(${v.id}, ${id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button></div>`).join('');
  const linhas = hist.map(h => `<tr><td>${fmtData(h.data)}</td><td style="text-align:center">${h.quantidade}</td>
    <td>${esc(h.origem)} <i class="ti ti-arrow-right" aria-hidden="true"></i> <b>${esc(h.destino)}</b></td>
    <td style="color:var(--text-muted)">${esc(h.observacao || '')}</td></tr>`).join('');
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal" style="max-width:640px">
        <div class="modal-header"><span class="modal-title">Histórico · ${esc(f.nome)}</span><button class="btn" onclick="fecharModal()"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div style="max-height:70vh;overflow:auto">
        <div class="hist-sec"><span><i class="ti ti-map-pin" aria-hidden="true"></i> Onde foi vista</span><button class="btn btn-visto" onclick="abrirModalVisto(${id})"><i class="ti ti-plus" aria-hidden="true"></i> Vi aqui</button></div>
        ${lv || '<p class="empty" style="padding:8px 0">Ainda não foi registrado onde foi vista.</p>'}
        <div class="hist-sec"><span><i class="ti ti-arrows-exchange" aria-hidden="true"></i> Movimentações</span></div>
        <table>
          <thead><tr><th>Data</th><th style="text-align:center">Qtd</th><th>Movimento</th><th>Obs.</th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="4" class="empty">Sem movimentações</td></tr>'}</tbody>
        </table></div>
      </div>
    </div>`;
  carregarFotosVisto(document.getElementById('modal-root'));
}

// ── CALENDÁRIO DO FUNCIONÁRIO (dias trabalhados no mês) ───────
const CORES_OBRA = ['#2563eb', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899', '#84cc16', '#f97316', '#64748b'];
const DIAS_SEM = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];

function abrirCalendario(eid, ano, mes) {
  const e = S.eletricistas.find(x => x.id === eid);
  if (!e) { toast('Funcionário não encontrado', 'erro'); return; }
  S.cal = { eid, ano: ano || S.finAno, mes: mes || S.finMes, dados: null, dia: null };
  renderCalendario();
  carregarCalendario();
}
function abrirCalendarioPorNome(nome) {
  const e = S.eletricistas.find(x => x.nome === nome);
  if (e) abrirCalendario(e.id);
}

async function carregarCalendario() {
  const c = S.cal; if (!c) return;
  const ini = `${c.ano}-${String(c.mes).padStart(2, '0')}-01`;
  const ult = new Date(c.ano, c.mes, 0).getDate();
  const fim = `${c.ano}-${String(c.mes).padStart(2, '0')}-${ult}`;
  try {
    const lista = await req('GET', `/apontamentos/?eletricista_id=${c.eid}&data_inicio=${ini}&data_fim=${fim}`) || [];
    if (S.cal !== c) return;              // usuário já fechou ou trocou
    c.dados = lista; renderCalendario();
  } catch (err) { toast(err.message, 'erro'); }
  carregarPagamentoCal();
}

function mudarMesCal(delta) {
  const c = S.cal; let m = c.mes + delta, a = c.ano;
  if (m < 1) { m = 12; a--; } if (m > 12) { m = 1; a++; }
  c.mes = m; c.ano = a; c.dados = null; c.dia = null; c.edit = null; c.comps = undefined; c.folhaLinha = null; renderCalendario(); carregarCalendario();
}
function selecionarDiaCal(d) { if (S.cal.edit) return; S.cal.dia = S.cal.dia === d ? null : d; renderCalendario(); }
function fecharCalendario() {
  const alterou = S.cal?.alterou; S.cal = null; fecharModal();
  if (alterou) { carregarDados(); if (S.tela === 'dashboard') carregarDash(); else renderMain(); }
}

function renderCalendario() {
  const c = S.cal; if (!c) return;
  const e = S.eletricistas.find(x => x.id === c.eid) || { nome: '' };
  const porDia = {};
  (c.dados || []).forEach(a => { porDia[+a.data.slice(8, 10)] = a; });

  // cor fixa por obra dentro do mês (a que tem mais gasto fica azul)
  const totObra = {};
  (c.dados || []).forEach(a => a.itens.forEach(i => { totObra[i.obra_nome] = (totObra[i.obra_nome] || 0) + i.valor; }));
  const obrasOrd = Object.keys(totObra).sort((a, b) => totObra[b] - totObra[a]);
  const cor = n => CORES_OBRA[obrasOrd.indexOf(n) % CORES_OBRA.length] || '#64748b';

  const totalMes = (c.dados || []).reduce((s, a) => s + a.total_dia, 0);
  const diasTrab = (c.dados || []).length;
  const hoje = new Date(); const ehHoje = d => hoje.getFullYear() === c.ano && hoje.getMonth() + 1 === c.mes && hoje.getDate() === d;

  const primeiroDia = new Date(c.ano, c.mes - 1, 1).getDay();
  const nDias = new Date(c.ano, c.mes, 0).getDate();
  let cels = '';
  for (let i = 0; i < primeiroDia; i++) cels += '<div class="cal-cel cal-vazia"></div>';
  for (let d = 1; d <= nDias; d++) {
    const a = porDia[d]; const sem = (primeiroDia + d - 1) % 7; const fds = sem === 0 || sem === 6;
    const obras = a ? a.itens : [];
    const barras = obras.map(i => `<span class="cal-barra" style="background:${cor(i.obra_nome)}" title="${esc(i.obra_nome)}"></span>`).join('');
    const nomeObra = obras.length ? `<span class="cal-obra">${esc(obras.length > 1 ? obras.length + ' obras' : obras[0].obra_nome)}</span>` : '';
    cels += `<button class="cal-cel ${a ? 'cal-trab' : ''} ${fds ? 'cal-fds' : ''} ${c.dia === d ? 'cal-sel' : ''} ${ehHoje(d) ? 'cal-hoje' : ''}" onclick="${a ? `selecionarDiaCal(${d})` : `editarDiaCal(${d})`}" ${a ? '' : `title="Lançar diária em ${d}"`}
      style="${a ? `--cor:${cor(obras[0]?.obra_nome)}` : ''}">
      <span class="cal-num">${d}</span>
      ${a ? `<span class="cal-val">${fmtBR(a.total_dia).replace(',00', '')}</span>${nomeObra}<span class="cal-barras">${barras}</span>` : ''}
    </button>`;
  }

  const legenda = obrasOrd.map(n => {
    const dias = (c.dados || []).filter(a => a.itens.some(i => i.obra_nome === n)).length;
    return `<div class="cal-leg"><span class="cal-leg-cor" style="background:${cor(n)}"></span><span class="cal-leg-nome">${esc(n)}</span><span class="cal-leg-val">${dias} dia(s) · R$ ${fmtBR(totObra[n])}</span></div>`;
  }).join('');

  let detalhe = '';
  if (c.dia && porDia[c.dia]) {
    const a = porDia[c.dia];
    const dt = new Date(c.ano, c.mes - 1, c.dia);
    detalhe = `<div class="cal-detalhe">
      <div class="cal-det-tit">${DIAS_SEM[dt.getDay()]}, ${c.dia}/${String(c.mes).padStart(2, '0')}/${c.ano}<span>R$ ${fmtBR(a.total_dia)}</span></div>
      ${a.itens.map(i => `<div class="cal-det-lin"><span><span class="cal-leg-cor" style="background:${cor(i.obra_nome)}"></span>${esc(i.obra_nome)}</span><b>R$ ${fmtBR(i.valor)}</b></div>`).join('')}
      ${a.adicionais.map(x => `<div class="cal-det-lin"><span>+ ${esc(x.tipo_label)}${x.descricao ? ': ' + esc(x.descricao) : ''}</span><b>R$ ${fmtBR(x.valor)}</b></div>`).join('')}
      ${a.observacao ? `<div class="cal-det-obs">${esc(a.observacao)}</div>` : ''}
      <div class="cal-det-acoes">
        <button class="btn btn-p" onclick="editarDiaCal(${c.dia})"><i class="ti ti-edit" aria-hidden="true"></i> Editar diária</button>
        <button class="btn" onclick="excluirDiaCal(${a.id}, ${c.dia})" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i> Excluir</button>
      </div>
    </div>`;
  }
  if (c.edit) detalhe = formEdicaoCal();

  const carregando = c.dados === null;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharCalendario()">
      <div class="modal modal-cal">
        <div class="modal-header">
          <div style="min-width:0"><div class="modal-title">${esc(e.nome)}</div>
            <div style="font-size:12px;color:#9aa5b4">${e.tipo_contrato === 'Mensalista' ? 'Mensalista · fixo R$ ' + fmtBR(e.salario_fixo) : 'Diária R$ ' + fmtBR(e.valor_diaria)}</div></div>
          <button class="btn" onclick="fecharCalendario()" aria-label="Fechar"><i class="ti ti-x" aria-hidden="true"></i></button>
        </div>
        <div class="cal-nav">
          <button class="btn" onclick="mudarMesCal(-1)" aria-label="Mês anterior"><i class="ti ti-chevron-left" aria-hidden="true"></i></button>
          <div class="cal-mes">${MESES[c.mes - 1]} de ${c.ano}</div>
          <button class="btn" onclick="mudarMesCal(1)" aria-label="Próximo mês"><i class="ti ti-chevron-right" aria-hidden="true"></i></button>
        </div>
        <div class="cal-resumo">
          <div><b>${carregando ? '…' : diasTrab}</b><span>dias trabalhados</span></div>
          <div><b>${carregando ? '…' : 'R$ ' + fmtBR(totalMes)}</b><span>no mês</span></div>
          <div><b>${carregando ? '…' : obrasOrd.length}</b><span>obra(s)</span></div>
        </div>
        <div class="cal-grade">${DIAS_SEM.map(d => `<div class="cal-sem">${d}</div>`).join('')}${cels}</div>
        ${carregando ? '<div class="loading" style="height:60px"><div class="spinner"></div></div>' : ''}
        ${detalhe || (carregando ? '' : '<p class="cal-dica">Toque num dia marcado para ver, editar ou excluir. Toque num dia vazio para lançar uma diária.</p>')}
        ${legenda ? `<div class="cal-legenda">${legenda}</div>` : ''}
        ${c.edit ? '' : blocoPagamentoCal()}
      </div>
    </div>`;
}

// ── Edição de diária dentro do calendário ─────────────────────
const TIPOS_AD = { hora_extra: 'Hora extra', sabado_feriado: 'Sábado/Feriado', semana_pesada: 'Semana pesada', outro: 'Outro' };
function diariaFunc() { const e = S.eletricistas.find(x => x.id === S.cal?.eid); return e?.valor_diaria || 0; }

function editarDiaCal(d) {
  const c = S.cal; const a = (c.dados || []).find(x => +x.data.slice(8, 10) === d);
  const data = `${c.ano}-${String(c.mes).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  c.dia = d;
  c.edit = a
    ? { id: a.id, data, dataOrig: data, observacao: a.observacao || '',
        itens: a.itens.map(i => ({ obra_id: i.obra_id, valor: i.valor })),
        adicionais: a.adicionais.map(x => ({ tipo: x.tipo, descricao: x.descricao, valor: x.valor })) }
    : { id: null, data, dataOrig: null, observacao: '', itens: [{ obra_id: '', valor: diariaFunc() }], adicionais: [] };
  renderCalendario();
}
function cancelarEdicaoCal() { S.cal.edit = null; renderCalendario(); }

function lerFormCal() {
  const ed = S.cal.edit;
  ed.data = document.getElementById('ce-data')?.value || ed.data;
  ed.observacao = document.getElementById('ce-obs')?.value || '';
  ed.itens = [...document.querySelectorAll('.ce-item')].map(r => ({ obra_id: r.querySelector('.ce-obra').value, valor: r.querySelector('.ce-valor').value }));
  ed.adicionais = [...document.querySelectorAll('.ce-ad')].map(r => ({ tipo: r.querySelector('.ce-ad-tipo').value, descricao: r.querySelector('.ce-ad-desc').value, valor: r.querySelector('.ce-ad-valor').value }));
}
function addItemCal() { lerFormCal(); S.cal.edit.itens.push({ obra_id: '', valor: '' }); renderCalendario(); }
function remItemCal(i) { lerFormCal(); S.cal.edit.itens.splice(i, 1); renderCalendario(); }
function addAdCal() { lerFormCal(); S.cal.edit.adicionais.push({ tipo: 'hora_extra', descricao: '', valor: '' }); renderCalendario(); }
function remAdCal(i) { lerFormCal(); S.cal.edit.adicionais.splice(i, 1); renderCalendario(); }
function preencherValorCal(i, fator) { lerFormCal(); S.cal.edit.itens[i].valor = +(diariaFunc() * fator).toFixed(2); renderCalendario(); }
function totalEdicaoCal() {
  const ed = S.cal.edit;
  return ed.itens.reduce((s, i) => s + (parseFloat(i.valor) || 0), 0) + ed.adicionais.reduce((s, x) => s + (parseFloat(x.valor) || 0), 0);
}
function atualizarTotalCal() { lerFormCal(); const el = document.getElementById('ce-total'); if (el) el.textContent = 'R$ ' + fmtBR(totalEdicaoCal()); }

function formEdicaoCal() {
  const ed = S.cal.edit; const diaria = diariaFunc();
  const obrasOrd = [...S.obras].sort((a, b) => a.nome.localeCompare(b.nome));
  const itens = ed.itens.map((it, i) => `
    <div class="ce-item">
      <select class="ce-obra" onchange="atualizarTotalCal()"><option value="">Selecione a obra...</option>${obrasOrd.map(o => `<option value="${o.id}" ${String(o.id) === String(it.obra_id) ? 'selected' : ''}>${esc(o.nome)}</option>`).join('')}</select>
      <div class="ce-linha">
        <input class="ce-valor" type="number" step="0.01" inputmode="decimal" placeholder="R$ valor" value="${it.valor}" oninput="atualizarTotalCal()" />
        ${diaria ? `<button class="btn" type="button" onclick="preencherValorCal(${i},1)">1 diária</button><button class="btn" type="button" onclick="preencherValorCal(${i},0.5)">½</button>` : ''}
        ${ed.itens.length > 1 ? `<button class="btn" type="button" onclick="remItemCal(${i})" style="color:var(--text-danger)" aria-label="Remover obra"><i class="ti ti-trash" aria-hidden="true"></i></button>` : ''}
      </div>
    </div>`).join('');
  const ads = ed.adicionais.map((x, i) => `
    <div class="ce-ad">
      <div class="ce-linha">
        <select class="ce-ad-tipo">${Object.entries(TIPOS_AD).map(([k, v]) => `<option value="${k}" ${x.tipo === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
        <input class="ce-ad-valor" type="number" step="0.01" inputmode="decimal" placeholder="R$" value="${x.valor}" oninput="atualizarTotalCal()" />
        <button class="btn" type="button" onclick="remAdCal(${i})" style="color:var(--text-danger)" aria-label="Remover adicional"><i class="ti ti-trash" aria-hidden="true"></i></button>
      </div>
      <input class="ce-ad-desc" placeholder="Descrição (ex: 2h extra)" value="${esc(x.descricao || '')}" />
    </div>`).join('');
  return `<div class="cal-detalhe cal-edit">
    <div class="cal-det-tit">${ed.id ? 'Editar diária' : 'Lançar diária'}<span id="ce-total">R$ ${fmtBR(totalEdicaoCal())}</span></div>
    <div class="field"><label>Data</label><input id="ce-data" type="date" value="${ed.data}" /></div>
    <div class="ce-sub">Obras do dia</div>
    ${itens}
    <button class="btn" type="button" onclick="addItemCal()"><i class="ti ti-plus" aria-hidden="true"></i> Outra obra no mesmo dia</button>
    <div class="ce-sub">Adicionais <span style="font-weight:400;color:#9aa5b4">(hora extra, sábado...)</span></div>
    ${ads}
    <button class="btn" type="button" onclick="addAdCal()"><i class="ti ti-plus" aria-hidden="true"></i> Adicional</button>
    <div class="field" style="margin-top:10px"><label>Observação</label><input id="ce-obs" value="${esc(ed.observacao)}" placeholder="Ex: meia diária, choveu..." /></div>
    <div class="modal-footer">
      <button class="btn" type="button" onclick="cancelarEdicaoCal()">Cancelar</button>
      <button class="btn btn-p" type="button" onclick="salvarEdicaoCal()"><i class="ti ti-device-floppy" aria-hidden="true"></i> Salvar</button>
    </div>
  </div>`;
}

async function salvarEdicaoCal() {
  lerFormCal();
  const c = S.cal, ed = c.edit;
  const itens = ed.itens.filter(i => i.obra_id || parseFloat(i.valor)).map(i => ({ obra_id: +i.obra_id, valor: parseFloat(i.valor) || 0 }));
  if (!itens.length) { toast('Adicione pelo menos uma obra', 'erro'); return; }
  if (itens.some(i => !i.obra_id)) { toast('Escolha a obra em todas as linhas', 'erro'); return; }
  if (itens.some(i => i.valor <= 0)) { toast('Informe o valor de cada obra', 'erro'); return; }
  const adicionais = ed.adicionais.filter(x => parseFloat(x.valor) > 0)
    .map(x => ({ tipo: x.tipo, descricao: x.descricao?.trim() || TIPOS_AD[x.tipo], valor: parseFloat(x.valor) }));
  if (!ed.data) { toast('Informe a data', 'erro'); return; }
  const mudouData = ed.dataOrig && ed.data !== ed.dataOrig;
  const ocupado = (c.dados || []).some(a => a.data === ed.data && a.id !== ed.id);
  if ((mudouData || !ed.id) && ocupado && !confirm(`Já existe diária em ${fmtData(ed.data)}. Substituir pela nova?`)) return;
  try {
    await req('POST', '/apontamentos/', { eletricista_id: c.eid, data: ed.data, observacao: ed.observacao.trim() || null, itens, adicionais });
    if (mudouData && ed.id) await req('DELETE', `/apontamentos/${ed.id}`);
    c.alterou = true; c.edit = null;
    const d = new Date(ed.data + 'T12:00:00');
    if (d.getFullYear() !== c.ano || d.getMonth() + 1 !== c.mes) { c.ano = d.getFullYear(); c.mes = d.getMonth() + 1; }
    c.dia = d.getDate(); c.dados = null;
    toast('Diária salva!'); renderCalendario(); carregarCalendario();
  } catch (err) { toast(err.message, 'erro'); }
}

async function excluirDiaCal(id, d) {
  if (!confirm(`Excluir a diária do dia ${d}? Isso tira o valor da obra e da folha.`)) return;
  try {
    await req('DELETE', `/apontamentos/${id}`);
    S.cal.alterou = true; S.cal.dia = null; S.cal.dados = null;
    toast('Diária excluída!'); renderCalendario(); carregarCalendario();
  } catch (err) { toast(err.message, 'erro'); }
}

// ── USUÁRIOS (quem entra no app) ───────────────────────────────
async function carregarUsuarios() {
  const main = document.getElementById('main');
  if (S.tela !== 'usuarios' || !main) return;
  if (!S.usuarios) main.innerHTML = '<div class="loading"><div class="spinner"></div><p>Carregando...</p></div>';
  try { S.usuarios = await req('GET', '/auth/usuarios') || []; renderUsuarios(main); }
  catch (err) { main.innerHTML = `<div class="content"><p class="empty">${esc(err.message)}</p></div>`; }
}

function usuarioLogado() { try { return JSON.parse(localStorage.getItem('az_user') || '{}'); } catch { return {}; } }

function mostrarUsuarioLogado() {
  const u = usuarioLogado();
  const txt = u.nome ? u.nome + (u.cargo ? ' · ' + u.cargo : '') : '';
  const a = document.getElementById('usuario-nome'); if (a) a.textContent = txt;
  const b = document.getElementById('mh-user'); if (b) b.textContent = u.nome || '';
}

async function atualizarUsuarioLogado() {
  try { const me = await req('GET', '/auth/me'); if (me) { localStorage.setItem('az_user', JSON.stringify(me)); mostrarUsuarioLogado(); } } catch {}
}

function renderUsuarios(main) {
  const eu = usuarioLogado().id;
  const linhas = (S.usuarios || []).map(u => `
    <tr style="${u.ativo ? '' : 'opacity:.55'}">
      <td><div class="elet-cell">
        <div class="av" style="background:#fef3c7;color:#a16207">${esc(u.nome.replace(/^ENG\.?\s*/i, '').split(' ').map(p => p[0]).slice(0, 2).join('').toUpperCase())}</div>
        <div><div style="font-size:13px;font-weight:600;color:var(--text-primary)">${esc(u.nome)}${u.id === eu ? ' <span class="badge b-g" style="margin-left:4px">você</span>' : ''}</div>
          <div style="font-size:11px;color:var(--text-muted)">${esc(u.cargo || '—')}</div></div></div></td>
      <td data-label="Login" style="color:var(--text-muted)">${esc(u.email)}${u.perfil === 'diarista' && u.senha_padrao ? ' <span class="badge" title="Ainda usa a senha 123456">senha 123456</span>' : ''}</td>
      <td data-label="Acesso"><span class="badge ${u.perfil === 'diarista' ? 'b-a' : 'b-b'}">${u.perfil === 'diarista' ? 'Diarista' : 'Escritório'}</span> <span class="badge ${u.ativo ? 'b-g' : ''}">${u.ativo ? 'Ativo' : 'Desativado'}</span></td>
      <td><div style="display:flex;gap:4px;justify-content:flex-end">
        ${u.perfil === 'diarista' ? `<button class="btn" onclick="resetarSenhaDiarista(${u.id})" title="Voltar a senha para 123456"><i class="ti ti-key" aria-hidden="true"></i> Resetar senha</button>` : ''}
        <button class="btn" onclick="abrirModalUsuario(${u.id})" title="Editar"><i class="ti ti-edit" aria-hidden="true"></i></button>
      </div></td></tr>`).join('');
  main.innerHTML = `
    <div class="topbar">
      <div><div class="topbar-title">Usuários</div><div class="topbar-sub">Escritório: acesso completo · Diaristas: só apontam a própria diária e as ferramentas</div></div>
      <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" onclick="gerarAcessosDiaristas()"><i class="ti ti-users-plus" aria-hidden="true"></i> Gerar acessos dos diaristas</button><button class="btn btn-p" onclick="abrirModalUsuario()"><i class="ti ti-user-plus" aria-hidden="true"></i> Novo usuário</button></div>
    </div>
    <div class="content">
      <div class="table-card">
        <table class="tbl-cards">
          <thead><tr><th>Nome</th><th>E-mail (login)</th><th>Acesso</th><th></th></tr></thead>
          <tbody>${linhas || '<tr><td colspan="4" class="empty">Nenhum usuário</td></tr>'}</tbody>
        </table>
      </div>
    </div>`;
}

function abrirModalUsuario(id) {
  const u = id ? (S.usuarios || []).find(x => x.id === id) : null;
  const eu = u && u.id === usuarioLogado().id;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal">
        <div class="modal-header"><span class="modal-title">${u ? (eu ? 'Meu perfil' : 'Editar usuário') : 'Novo usuário'}</span><button class="btn" onclick="fecharModal()" aria-label="Fechar"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="field"><label>Nome (como aparece no app) *</label><input id="mu-nome" value="${esc(u?.nome || '')}" placeholder="Ex: ELDO SANTOS AZEVEDO" /></div>
        <div class="field"><label>Cargo</label><input id="mu-cargo" value="${esc(u?.cargo || '')}" placeholder="Ex: CEO, Engenheiro, Encarregado" /></div>
        <div class="field"><label>E-mail (usado para entrar) *</label><input id="mu-email" type="email" autocomplete="off" value="${esc(u?.email || '')}" placeholder="nome@email.com" /></div>
        <div class="field"><label>${u ? 'Nova senha' : 'Senha *'} <span style="font-weight:400;color:var(--text-muted)">${u ? '(deixe em branco para manter a atual)' : '(mínimo 6 caracteres)'}</span></label>
          <input id="mu-senha" type="password" autocomplete="new-password" placeholder="••••••" /></div>
        ${u && !eu ? `<label style="display:flex;gap:8px;align-items:center;font-size:13px;margin:4px 0"><input id="mu-ativo" type="checkbox" ${u.ativo ? 'checked' : ''} style="width:auto" /> Pode entrar no app (ativo)</label>` : ''}
        ${u ? '' : '<p style="font-size:12px;color:var(--text-muted);margin:4px 0 0">O novo usuário terá acesso a tudo: obras, equipe, folha, financeiro, despesas, ferramentas e orçamentos.</p>'}
        <div class="modal-footer">
          <button class="btn" onclick="fecharModal()">Cancelar</button>
          <button class="btn btn-p" onclick="salvarUsuario(${u?.id || 'null'})">${u ? 'Salvar' : 'Criar usuário'}</button>
        </div>
      </div>
    </div>`;
  setTimeout(() => document.getElementById('mu-nome')?.focus(), 50);
}

async function gerarAcessosDiaristas() {
  if (!confirm('Criar o acesso de cada diarista ativo que ainda não tem?\n\nLogin: primeironome@gmail.com\nSenha inicial: 123456')) return;
  try {
    const r = await req('POST', '/auth/diaristas/gerar');
    await carregarUsuarios();
    const lista = (r.criados || []).map(c => `<tr><td>${esc(c.nome)}</td><td><b>${esc(c.email)}</b></td></tr>`).join('');
    document.getElementById('modal-root').innerHTML = `
      <div class="modal-overlay" onclick="if(event.target===this)fecharModal()"><div class="modal" style="max-width:520px">
        <div class="modal-header"><span class="modal-title">${(r.criados || []).length ? 'Acessos criados' : 'Nada a criar'}</span><button class="btn" onclick="fecharModal()" aria-label="Fechar"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        ${lista ? `<p style="font-size:13px;color:var(--text-muted);margin:0 0 8px">Senha inicial de todos: <b style="color:var(--text-primary)">${esc(r.senha)}</b>. Cada um pode trocar no próprio celular.</p>
        <div style="max-height:50vh;overflow:auto"><table><thead><tr><th>Funcionário</th><th>Login</th></tr></thead><tbody>${lista}</tbody></table></div>
        <button class="btn btn-whats btn-full" style="margin-top:12px" onclick="copiarAcessos()"><i class="ti ti-copy" aria-hidden="true"></i> Copiar lista para o WhatsApp</button>` : '<p style="font-size:13px">Todos os diaristas ativos já têm acesso.</p>'}
      </div></div>`;
    S.acessosCriados = r;
  } catch (err) { toast(err.message, 'erro'); }
}
function copiarAcessos() {
  const r = S.acessosCriados; if (!r) return;
  const txt = `*AZ Elétrica — acesso da equipe*\nApp: ${location.origin}\nSenha inicial: ${r.senha} (troque no primeiro acesso)\n\n` + r.criados.map(c => `${c.nome}: ${c.email}`).join('\n');
  navigator.clipboard.writeText(txt).then(() => toast('Lista copiada! Cole no WhatsApp.')).catch(() => toast('Não foi possível copiar', 'erro'));
}
async function resetarSenhaDiarista(id) {
  const u = S.usuarios.find(x => x.id === id);
  if (!confirm(`Voltar a senha de ${u.nome} para 123456?`)) return;
  try { await req('PUT', `/auth/usuarios/${id}`, { nome: u.nome, cargo: u.cargo, email: u.email, ativo: u.ativo, nova_senha: '123456' }); toast('Senha voltou para 123456'); carregarUsuarios(); }
  catch (err) { toast(err.message, 'erro'); }
}

async function salvarUsuario(id) {
  const nome = document.getElementById('mu-nome').value.trim();
  const cargo = document.getElementById('mu-cargo').value.trim();
  const email = document.getElementById('mu-email').value.trim();
  const senha = document.getElementById('mu-senha').value;
  const ativoEl = document.getElementById('mu-ativo');
  if (!nome || !email) { toast('Preencha nome e e-mail', 'erro'); return; }
  if (!id && senha.length < 6) { toast('A senha precisa ter pelo menos 6 caracteres', 'erro'); return; }
  if (id && senha && senha.length < 6) { toast('A nova senha precisa ter pelo menos 6 caracteres', 'erro'); return; }
  try {
    if (id) {
      const atual = S.usuarios.find(x => x.id === id);
      await req('PUT', `/auth/usuarios/${id}`, { nome, cargo: cargo || null, email, ativo: ativoEl ? ativoEl.checked : atual.ativo, nova_senha: senha || null });
      if (id === usuarioLogado().id) await atualizarUsuarioLogado();
    } else {
      await req('POST', '/auth/registro', { nome, cargo: cargo || null, email, senha });
    }
    fecharModal(); toast(id ? 'Usuário atualizado!' : 'Usuário criado!'); carregarUsuarios();
  } catch (err) { toast(err.message, 'erro'); }
}

// ── PAGAMENTO DO MÊS: comprovantes, PDF de resumo e envio ─────
async function reqArquivo(path) {
  const res = await fetch(API + path, { headers: { Authorization: 'Bearer ' + window._TOKEN } });
  if (res.status === 401) { logout(); throw new Error('Sessão expirada'); }
  if (!res.ok) { const e = await res.json().catch(() => ({})); throw new Error(e?.detail || 'Erro ' + res.status); }
  const nome = (/filename="([^"]+)"/.exec(res.headers.get('content-disposition') || '') || [])[1] || 'arquivo';
  return { blob: await res.blob(), nome };
}

async function carregarPagamentoCal() {
  const c = S.cal; if (!c) return;
  try {
    const [comps, folha] = await Promise.all([
      req('GET', `/comprovantes?eletricista_id=${c.eid}&ano=${c.ano}&mes=${c.mes}`),
      req('GET', `/financeiro/folha?ano=${c.ano}&mes=${c.mes}`),
    ]);
    if (S.cal !== c) return;
    c.comps = comps || []; c.folhaLinha = (folha?.linhas || []).find(l => l.eletricista_id === c.eid) || null;
    renderCalendario();
  } catch (err) { toast(err.message, 'erro'); }
}

function blocoPagamentoCal() {
  const c = S.cal;
  if (c.comps === undefined) return '<div class="cal-pag"><div class="loading" style="height:50px"><div class="spinner"></div></div></div>';
  const fl = c.folhaLinha;
  const comps = (c.comps || []).map(cp => `
    <div class="pg-comp">
      <i class="ti ${cp.mime === 'application/pdf' ? 'ti-file-type-pdf' : 'ti-photo'}" aria-hidden="true"></i>
      <div class="pg-comp-info"><b>${cp.data_pagamento ? fmtData(cp.data_pagamento) : fmtData(cp.criado_em.slice(0, 10))}${cp.valor ? ' · R$ ' + fmtBR(cp.valor) : ''}</b>
        <span>${esc(cp.observacao || cp.nome_arquivo)}</span></div>
      <button class="btn" onclick="verComprovante(${cp.id})" title="Ver"><i class="ti ti-eye" aria-hidden="true"></i></button>
      <button class="btn" onclick="excluirComprovante(${cp.id})" title="Excluir" style="color:var(--text-danger)"><i class="ti ti-trash" aria-hidden="true"></i></button>
    </div>`).join('');
  return `<div class="cal-pag">
    <div class="pg-topo">
      <div><div class="ce-sub" style="margin:0">Pagamento de ${MESES[c.mes - 1]}</div>
        ${fl ? `<div class="pg-receber">A receber: <b>R$ ${fmtBR(fl.a_receber)}</b></div>` : '<div class="pg-receber" style="color:#9aa5b4">Sem valores neste mês</div>'}</div>
      ${(c.comps || []).length ? '<span class="badge b-g"><i class="ti ti-check" aria-hidden="true"></i> Comprovante anexado</span>' : '<span class="badge b-a">Sem comprovante</span>'}
    </div>
    ${comps}
    <input type="file" id="pg-arquivo" accept="image/*,application/pdf" style="display:none" onchange="escolheuComprovante(this)" />
    <div id="pg-form">${c.arquivoPendente ? formComprovante(c.arquivoPendente) : ''}</div>
    <div class="pg-acoes">
      <button class="btn" onclick="document.getElementById('pg-arquivo').click()"><i class="ti ti-paperclip" aria-hidden="true"></i> Anexar comprovante</button>
      <button class="btn" onclick="abrirPdfResumo()"><i class="ti ti-file-type-pdf" aria-hidden="true"></i> PDF do mês</button>
      <button class="btn btn-p" onclick="enviarResumo()"><i class="ti ti-send" aria-hidden="true"></i> Enviar</button>
    </div>
  </div>`;
}

// reduz fotos grandes antes de enviar (economiza espaço no banco e dados móveis)
function comprimirImagem(file, max = 1600, qualidade = 0.82) {
  return new Promise(resolve => {
    if (!file.type.startsWith('image/') || file.size < 400 * 1024) return resolve(file);
    const img = new Image(); const url = URL.createObjectURL(file);
    img.onload = () => {
      const esc_ = Math.min(1, max / Math.max(img.width, img.height));
      const cv = document.createElement('canvas'); cv.width = Math.round(img.width * esc_); cv.height = Math.round(img.height * esc_);
      cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
      cv.toBlob(b => { URL.revokeObjectURL(url); resolve(b && b.size < file.size ? new File([b], file.name.replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file); }, 'image/jpeg', qualidade);
    };
    img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };   // ex: HEIC fora do Safari
    img.src = url;
  });
}

function escolheuComprovante(inp) {
  const f = inp.files?.[0]; if (!f) return;
  S.cal.arquivoPendente = f; inp.value = '';
  document.getElementById('pg-form').innerHTML = formComprovante(f);
  document.getElementById('pg-form').scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function formComprovante(f) {
  const fl = S.cal.folhaLinha;
  return `
    <div class="pg-novo">
      <div class="pg-novo-arq"><i class="ti ${f.type === 'application/pdf' ? 'ti-file-type-pdf' : 'ti-photo'}" aria-hidden="true"></i> ${esc(f.name)} <span>(${(f.size / 1024 / 1024).toFixed(1)} MB)</span></div>
      <div class="ce-linha">
        <input id="pg-valor" type="number" step="0.01" inputmode="decimal" placeholder="Valor pago" value="${fl && fl.a_receber > 0 ? fl.a_receber : ''}" />
        <input id="pg-data" type="date" value="${new Date().toISOString().slice(0, 10)}" />
      </div>
      <input id="pg-obs" placeholder="Observação (ex: Pix Inter)" />
      <div class="ce-linha" style="justify-content:flex-end">
        <button class="btn" onclick="cancelarComprovante()">Cancelar</button>
        <button class="btn btn-p" id="pg-salvar" onclick="salvarComprovante()"><i class="ti ti-upload" aria-hidden="true"></i> Salvar comprovante</button>
      </div>
    </div>`;
}
function cancelarComprovante() { S.cal.arquivoPendente = null; document.getElementById('pg-form').innerHTML = ''; }

async function salvarComprovante() {
  const c = S.cal; const f0 = c.arquivoPendente; if (!f0) return;
  const btn = document.getElementById('pg-salvar'); if (btn) { btn.disabled = true; btn.textContent = 'Enviando...'; }
  try {
    const f = await comprimirImagem(f0);
    if (f.size > 8 * 1024 * 1024) throw new Error('Arquivo maior que 8 MB');
    const fd = new FormData();
    fd.append('eletricista_id', c.eid); fd.append('ano', c.ano); fd.append('mes', c.mes);
    const v = document.getElementById('pg-valor').value; if (v) fd.append('valor', v);
    const d = document.getElementById('pg-data').value; if (d) fd.append('data_pagamento', d);
    const o = document.getElementById('pg-obs').value.trim(); if (o) fd.append('observacao', o);
    fd.append('arquivo', f, f.name);
    const res = await fetch(API + '/comprovantes', { method: 'POST', headers: { Authorization: 'Bearer ' + window._TOKEN }, body: fd });
    if (!res.ok) { const e = await res.json().catch(() => ({})); throw new Error(e?.detail || 'Erro ' + res.status); }
    c.arquivoPendente = null; c.alterou = true;
    toast('Comprovante salvo!'); carregarPagamentoCal();
  } catch (err) { toast(err.message, 'erro'); if (btn) { btn.disabled = false; btn.textContent = 'Salvar comprovante'; } }
}

async function verComprovante(id) {
  const janela = window.open('', '_blank');           // abre já no clique (evita bloqueio de pop-up)
  try {
    const { blob } = await reqArquivo(`/comprovantes/${id}/arquivo`);
    const url = URL.createObjectURL(blob);
    if (janela) janela.location.href = url; else window.location.href = url;
  } catch (err) { if (janela) janela.close(); toast(err.message, 'erro'); }
}

async function excluirComprovante(id) {
  if (!confirm('Excluir este comprovante?')) return;
  try { await req('DELETE', `/comprovantes/${id}`); S.cal.alterou = true; toast('Comprovante excluído'); carregarPagamentoCal(); }
  catch (err) { toast(err.message, 'erro'); }
}

async function pdfResumoArquivo() {
  const c = S.cal;
  const { blob } = await reqArquivo(`/relatorios/funcionario/${c.eid}/pdf?ano=${c.ano}&mes=${c.mes}`);
  const e = S.eletricistas.find(x => x.id === c.eid) || { nome: 'funcionario' };
  const nome = 'Resumo_' + e.nome.normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^\w]+/g, '_') + `_${String(c.mes).padStart(2, '0')}-${c.ano}.pdf`;
  return new File([blob], nome, { type: 'application/pdf' });
}

async function abrirPdfResumo() {
  const janela = window.open('', '_blank');
  toast('Gerando PDF...');
  try {
    const f = await pdfResumoArquivo();
    const url = URL.createObjectURL(f);
    if (janela) janela.location.href = url; else baixarArquivo(f);
  } catch (err) { if (janela) janela.close(); toast(err.message, 'erro'); }
}

function baixarArquivo(f) {
  const a = document.createElement('a'); a.href = URL.createObjectURL(f); a.download = f.name;
  document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
}

async function enviarResumo() {
  const c = S.cal; const e = S.eletricistas.find(x => x.id === c.eid) || {};
  toast('Preparando arquivos...');
  try {
    const arquivos = [await pdfResumoArquivo()];
    for (const cp of (c.comps || [])) {
      const { blob } = await reqArquivo(`/comprovantes/${cp.id}/arquivo`);
      const ext = cp.mime === 'application/pdf' ? 'pdf' : (cp.mime.split('/')[1] || 'jpg').replace('jpeg', 'jpg');
      arquivos.push(new File([blob], `Comprovante_${(e.nome || '').replace(/\s+/g, '_')}_${String(c.mes).padStart(2, '0')}-${c.ano}${c.comps.length > 1 ? '_' + cp.id : ''}.${ext}`, { type: cp.mime }));
    }
    const fl = c.folhaLinha;
    const texto = `Olá, ${(e.nome || '').split(' ')[0]}! Segue o resumo das suas diárias de ${MESES[c.mes - 1]}/${c.ano}` +
      (fl ? ` (valor a receber: R$ ${fmtBR(fl.a_receber)})` : '') + ((c.comps || []).length ? ' e o comprovante de pagamento.' : '.') + ' — AZ Elétrica';
    if (navigator.canShare && navigator.canShare({ files: arquivos })) {
      await navigator.share({ files: arquivos, title: `Resumo ${MESES[c.mes - 1]}/${c.ano}`, text: texto });
      return;
    }
    // computador: baixa os arquivos e abre o WhatsApp com a mensagem pronta
    arquivos.forEach((f, i) => setTimeout(() => baixarArquivo(f), i * 400));
    const fone = (e.telefone || '').replace(/\D/g, '');
    const num = fone ? (fone.length <= 11 ? '55' + fone : fone) : '';
    window.open(`https://wa.me/${num}?text=${encodeURIComponent(texto)}`, '_blank');
    toast('Arquivos baixados. No WhatsApp, clique no clipe e anexe-os.');
  } catch (err) { if (err?.name !== 'AbortError') toast(err.message, 'erro'); }
}

function fecharModal() { document.getElementById('modal-root').innerHTML = ''; }

// ── NOTIFICAÇÕES (sininho + push no celular) ─────────────────
let _sinoTimer = null;
function iniciarSino() { pararSino(); atualizarSino(); _sinoTimer = setInterval(atualizarSino, 60000); }
function pararSino() { if (_sinoTimer) clearInterval(_sinoTimer); _sinoTimer = null; }
document.addEventListener('visibilitychange', () => { if (!document.hidden && _sinoTimer) atualizarSino(); });
async function atualizarSino() {
  try {
    const r = await req('GET', '/notificacoes?limite=30'); if (!r) return;
    const antes = S.notifNaoLidas || 0;
    S.notif = r; S.notifNaoLidas = r.nao_lidas;
    document.querySelectorAll('.sino-badge').forEach(b => { b.textContent = r.nao_lidas > 9 ? '9+' : r.nao_lidas; b.style.display = r.nao_lidas ? 'flex' : 'none'; });
    if (r.nao_lidas > antes && antes !== undefined && S._sinoIniciado) vibrar('aviso');
    S._sinoIniciado = true;
  } catch { /* offline */ }
}
function haTempo(iso) {
  const m = Math.round((Date.now() - new Date(iso)) / 60000);
  if (m < 1) return 'agora'; if (m < 60) return `há ${m} min`; const h = Math.round(m / 60);
  if (h < 24) return `há ${h} h`; const d = Math.round(h / 24); return d === 1 ? 'ontem' : `há ${d} dias`;
}
async function abrirSino() {
  await atualizarSino();
  const r = S.notif || { itens: [] };
  const ico = { diaria: 'ti-clock-check', obra: 'ti-map-pin-plus' };
  const pushOk = 'PushManager' in window && 'serviceWorker' in navigator && 'Notification' in window;
  const ativo = pushOk && Notification.permission === 'granted' && localStorage.getItem('az_push') === '1';
  const ios = /iP(hone|ad|od)/.test(navigator.userAgent), standalone = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;
  document.getElementById('modal-root').innerHTML = `
    <div class="modal-overlay" onclick="if(event.target===this)fecharModal()">
      <div class="modal" style="max-width:460px">
        <div class="modal-header"><span class="modal-title"><i class="ti ti-bell" aria-hidden="true"></i> Notificações</span><button class="btn" onclick="fecharModal()" aria-label="Fechar"><i class="ti ti-x" aria-hidden="true"></i></button></div>
        <div class="push-box ${ativo ? 'ok' : ''}">
          ${ativo ? `<i class="ti ti-device-mobile-check" aria-hidden="true"></i><div style="flex:1"><b>Avisos ativos neste celular</b><br><span>Você recebe quando um diarista apontar ou pedir obra.</span></div><button class="btn" onclick="testarPush()">Testar</button>`
      : !pushOk || (ios && !standalone) ? `<i class="ti ti-info-circle" aria-hidden="true"></i><div><b>Para receber avisos no celular</b><br><span>${ios ? 'No iPhone: abra no Safari › Compartilhar › "Adicionar à Tela de Início", entre pelo ícone e ative aqui.' : 'Este navegador não aceita notificações. Use o Chrome.'}</span></div>`
      : `<i class="ti ti-bell-ringing" aria-hidden="true"></i><div style="flex:1"><b>Receber avisos neste celular</b><br><span>Quando um diarista apontar a diária ou pedir obra nova.</span></div><button class="btn btn-p" onclick="ativarPush()">Ativar</button>`}
        </div>
        <div class="notif-lista">${(r.itens || []).map(n => `
          <button class="notif-item ${n.lida ? '' : 'nova'}" onclick="fecharModal();${n.link ? `navegar('${esc(n.link)}')` : ''}">
            <span class="ni-ico"><i class="ti ${ico[n.tipo] || 'ti-bell'}" aria-hidden="true"></i></span>
            <span style="flex:1;min-width:0;text-align:left"><span class="ni-tit">${esc(n.titulo)}</span><span class="ni-txt">${esc(n.texto || '')}</span><span class="ni-quando">${n.criado_em ? haTempo(n.criado_em) : ''}</span></span>
          </button>`).join('') || '<p class="empty">Nenhuma notificação ainda</p>'}</div>
      </div>
    </div>`;
  if (r.nao_lidas) { req('POST', '/notificacoes/lidas').then(() => { S.notifNaoLidas = 0; document.querySelectorAll('.sino-badge').forEach(b => b.style.display = 'none'); }).catch(() => {}); }
}
function b64ParaBytes(b64) {
  const p = '='.repeat((4 - b64.length % 4) % 4); const raw = atob((b64 + p).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...raw].map(c => c.charCodeAt(0)));
}
async function ativarPush() {
  try {
    const perm = await Notification.requestPermission();
    if (perm !== 'granted') { toast('Permissão negada. Libere as notificações nas configurações do navegador.', 'erro'); return; }
    const reg = await navigator.serviceWorker.register('/sw.js');
    await navigator.serviceWorker.ready;
    const { chave } = await req('GET', '/push/chave');
    let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ParaBytes(chave) });
    await req('POST', '/push/assinar', sub.toJSON());
    localStorage.setItem('az_push', '1');
    toast('Avisos ativados neste celular!'); abrirSino();
    req('POST', '/push/teste').catch(() => {});
  } catch (err) { toast('Não foi possível ativar: ' + err.message, 'erro'); }
}
async function testarPush() {
  try { await req('POST', '/push/teste'); toast('Enviado! Deve chegar em alguns segundos.'); } catch (err) { toast(err.message, 'erro'); }
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('login-form').onsubmit = handleLogin;
  document.getElementById('btn-logout').addEventListener('click', logout);
  document.querySelectorAll('.nav-item').forEach(el =>
    el.addEventListener('click', () => navegar(el.dataset.tela))
  );
  if (window._TOKEN) { iniciarApp(); } else { mostrarLogin(); }
});
