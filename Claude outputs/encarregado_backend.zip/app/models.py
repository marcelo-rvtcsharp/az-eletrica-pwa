from sqlalchemy import create_engine, Column, Integer, String, Float, Date, DateTime, ForeignKey, Text, Boolean, LargeBinary
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship, deferred
from datetime import datetime
import os

# Em produção (Railway) use um Volume montado em /data para o banco não
# ser apagado a cada deploy. Se a pasta /data existir, ela é usada
# automaticamente; a variável DATABASE_URL, se definida, tem prioridade.
_DB_PADRAO = "sqlite:////data/az_eletrica.db" if os.path.isdir("/data") else "sqlite:///./az_eletrica.db"
DATABASE_URL = os.getenv("DATABASE_URL", _DB_PADRAO).strip()

# Postgres (Neon): a connection string vem como "postgres://" ou
# "postgresql://"; aqui fixamos o driver psycopg2 (requirements.txt).
for _prefixo in ("postgres://", "postgresql://"):
    if DATABASE_URL.startswith(_prefixo):
        DATABASE_URL = "postgresql+psycopg2://" + DATABASE_URL[len(_prefixo):]
        break

if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    # pool_pre_ping: o Neon fecha conexões ociosas; isso evita erro no
    # primeiro acesso depois que o banco "dorme".
    engine = create_engine(DATABASE_URL, pool_pre_ping=True, pool_recycle=300)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# ── Usuários ────────────────────────────────────────────────────────────────
class Usuario(Base):
    __tablename__ = "usuarios"
    id          = Column(Integer, primary_key=True, index=True)
    nome        = Column(String, nullable=False)
    email       = Column(String, unique=True, nullable=False)
    senha_hash  = Column(String, nullable=False)
    perfil      = Column(String, default="admin")   # admin | diarista
    cargo       = Column(String)          # ex: "CEO", "Engenheiro"
    eletricista_id = Column(Integer)      # perfil diarista: qual funcionário é
    senha_padrao   = Column(Boolean, default=False)  # ainda usa a senha inicial
    ativo       = Column(Boolean, default=True)
    criado_em   = Column(DateTime, default=datetime.utcnow)


# ── Eletricistas ────────────────────────────────────────────────────────────
class Eletricista(Base):
    __tablename__ = "eletricistas"
    id            = Column(Integer, primary_key=True, index=True)
    nome          = Column(String, nullable=False)
    telefone      = Column(String)
    cpf           = Column(String)
    funcao        = Column(String, default="Eletricista")
    valor_diaria  = Column(Float, nullable=False)
    tipo_contrato = Column(String, default="Diarista")
    salario_fixo  = Column(Float, default=0)   # usado quando tipo_contrato == "Mensalista"
    nr10_validade = Column(Date, nullable=True)
    nr35_validade = Column(Date, nullable=True)
    data_entrada  = Column(Date, nullable=True)
    status        = Column(String, default="Ativo")
    criado_em     = Column(DateTime, default=datetime.utcnow)
    atualizadoEm  = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    apontamentos = relationship("ApontamentoItem", back_populates="eletricista")


# ── Obras ───────────────────────────────────────────────────────────────────
class Obra(Base):
    __tablename__ = "obras"
    id               = Column(Integer, primary_key=True, index=True)
    nome             = Column(String, nullable=False)
    cliente          = Column(String, nullable=False)
    contato          = Column(String)
    cidade           = Column(String)
    bairro           = Column(String)
    endereco         = Column(String)
    tipo_servico     = Column(String, default="Elétrica residencial")
    valor_contratado = Column(Float, nullable=False)
    data_inicio      = Column(Date, nullable=True)
    data_previsao    = Column(Date, nullable=True)
    data_conclusao   = Column(Date, nullable=True)
    status           = Column(String, default="Em andamento")
    alerta_percentual= Column(Integer, default=85)
    observacoes      = Column(Text)
    criado_em        = Column(DateTime, default=datetime.utcnow)
    atualizadoEm     = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    apontamentos = relationship("ApontamentoItem", back_populates="obra")


# ── Apontamentos ─────────────────────────────────────────────────────────────
class Apontamento(Base):
    """Cabeçalho — um por eletricista/dia"""
    __tablename__ = "apontamentos"
    id             = Column(Integer, primary_key=True, index=True)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False)
    data           = Column(Date, nullable=False)
    observacao     = Column(Text)
    criado_em      = Column(DateTime, default=datetime.utcnow)
    criado_por     = Column(Integer, ForeignKey("usuarios.id"))

    itens      = relationship("ApontamentoItem",     back_populates="apontamento", cascade="all, delete-orphan")
    adicionais = relationship("ApontamentoAdicional", back_populates="apontamento", cascade="all, delete-orphan")


class ApontamentoItem(Base):
    """Cada obra trabalhada no dia"""
    __tablename__ = "apontamento_itens"
    id             = Column(Integer, primary_key=True, index=True)
    apontamento_id = Column(Integer, ForeignKey("apontamentos.id"), nullable=False)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False)
    obra_id        = Column(Integer, ForeignKey("obras.id"), nullable=False)
    valor          = Column(Float, nullable=False)

    apontamento = relationship("Apontamento", back_populates="itens")
    eletricista = relationship("Eletricista", back_populates="apontamentos")
    obra        = relationship("Obra", back_populates="apontamentos")


class ApontamentoAdicional(Base):
    """Adicionais do dia: sábado/feriado, semana pesada, hora extra, outro"""
    __tablename__ = "apontamento_adicionais"
    id             = Column(Integer, primary_key=True, index=True)
    apontamento_id = Column(Integer, ForeignKey("apontamentos.id"), nullable=False)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False)
    tipo           = Column(String, nullable=False)
    # sabado_feriado | semana_pesada | hora_extra | outro
    descricao      = Column(String, nullable=False)
    valor          = Column(Float, nullable=False)

    apontamento = relationship("Apontamento", back_populates="adicionais")


# ── Orçamentos ───────────────────────────────────────────────────────────────
class Orcamento(Base):
    __tablename__ = "orcamentos"
    id               = Column(Integer, primary_key=True, index=True)
    numero           = Column(String, unique=True)
    cliente_nome     = Column(String)
    cliente_cnpj     = Column(String)
    cliente_endereco = Column(String)
    obra_descricao   = Column(String)
    data             = Column(Date)
    validade         = Column(Integer, default=10)
    status           = Column(String, default="Rascunho")
    obs              = Column(Text)
    criado_em        = Column(DateTime, default=datetime.utcnow)
    atualizadoEm     = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    itens = relationship("OrcamentoItem", back_populates="orcamento", cascade="all, delete-orphan")


class OrcamentoItem(Base):
    __tablename__ = "orcamento_itens"
    id           = Column(Integer, primary_key=True, index=True)
    orcamento_id = Column(Integer, ForeignKey("orcamentos.id"), nullable=False)
    descricao    = Column(String, nullable=False)
    und          = Column(String, default="UND")
    qtd          = Column(Float, default=0)
    vunit        = Column(Float, default=0)
    ordem        = Column(Integer, default=0)

    orcamento = relationship("Orcamento", back_populates="itens")


# ── Financeiro: adiantamentos, adicionais e descontos avulsos ──────────────
class LancamentoFinanceiro(Base):
    __tablename__ = "lancamentos_financeiros"
    id             = Column(Integer, primary_key=True, index=True)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False)
    data           = Column(Date, nullable=False)       # o mês desta data define a folha
    tipo           = Column(String, nullable=False)     # adiantamento | adicional | desconto
    valor          = Column(Float, nullable=False)
    descricao      = Column(String)
    criado_em      = Column(DateTime, default=datetime.utcnow)


# ── Financeiro: empréstimos descontados em parcelas mensais ────────────────
class Emprestimo(Base):
    __tablename__ = "emprestimos"
    id             = Column(Integer, primary_key=True, index=True)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False)
    descricao      = Column(String, nullable=False)     # Ex: "Moto", "Empréstimo"
    valor_total    = Column(Float, nullable=False)
    valor_parcela  = Column(Float, nullable=False)
    inicio         = Column(Date, nullable=False)       # mês da folha com a 1ª parcela
    observacao     = Column(Text)
    criado_em      = Column(DateTime, default=datetime.utcnow)


# ── Despesas do mês: alimentação, combustível, ferramentas... ──────────────
class Despesa(Base):
    __tablename__ = "despesas"
    id         = Column(Integer, primary_key=True, index=True)
    data       = Column(Date, nullable=False)
    categoria  = Column(String, nullable=False)   # alimentacao | combustivel | ferramentas | hospedagem | outros
    valor      = Column(Float, nullable=False)
    descricao  = Column(String)
    pessoas    = Column(Integer)                  # alimentação: nº de pessoas no dia
    obra_id    = Column(Integer, ForeignKey("obras.id"), nullable=True)
    automatica = Column(Boolean, default=False)   # True = calculada pelos apontamentos
    criado_em  = Column(DateTime, default=datetime.utcnow)


# ── Ferramentas: cadastro, onde está cada unidade e histórico ──────────────
class Ferramenta(Base):
    __tablename__ = "ferramentas"
    id               = Column(Integer, primary_key=True, index=True)
    nome             = Column(String, nullable=False)
    quantidade_total = Column(Integer, nullable=False, default=1)
    observacao       = Column(Text)
    criado_em        = Column(DateTime, default=datetime.utcnow)


class FerramentaLocal(Base):
    """Quantas unidades da ferramenta estão em cada obra.
    O que não está em nenhuma obra está no Depósito."""
    __tablename__ = "ferramenta_locais"
    id            = Column(Integer, primary_key=True, index=True)
    ferramenta_id = Column(Integer, ForeignKey("ferramentas.id"), nullable=False)
    obra_id       = Column(Integer, ForeignKey("obras.id"), nullable=False)
    quantidade    = Column(Integer, nullable=False)
    desde         = Column(Date)


class FerramentaMov(Base):
    __tablename__ = "ferramenta_movs"
    id            = Column(Integer, primary_key=True, index=True)
    ferramenta_id = Column(Integer, ForeignKey("ferramentas.id"), nullable=False)
    data          = Column(Date, nullable=False)
    quantidade    = Column(Integer, nullable=False)
    origem_nome   = Column(String)     # nome guardado como texto: o histórico continua
    destino_nome  = Column(String)     # legível mesmo se a obra for excluída
    observacao    = Column(String)
    criado_em     = Column(DateTime, default=datetime.utcnow)


class EquipeMembro(Base):
    """Equipe de um encarregado (usuário diarista): ele pode apontar a diária desses funcionários."""
    __tablename__ = "equipe_membros"
    id             = Column(Integer, primary_key=True, index=True)
    usuario_id     = Column(Integer, ForeignKey("usuarios.id"), nullable=False, index=True)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False)


class FerramentaVisto(Base):
    """'Último lugar visto': registro rápido de onde a ferramenta foi vista,
    com foto opcional. Não mexe nas quantidades por obra."""
    __tablename__ = "ferramenta_vistos"
    id             = Column(Integer, primary_key=True, index=True)
    ferramenta_id  = Column(Integer, ForeignKey("ferramentas.id"), nullable=False, index=True)
    data           = Column(Date, nullable=False)
    local          = Column(String, nullable=False)   # texto livre ou nome da obra
    obra_id        = Column(Integer)                  # opcional (sem FK: obra pode ser excluída)
    observacao     = Column(String)
    registrado_por = Column(String)
    foto_mime      = Column(String)
    foto           = deferred(Column(LargeBinary))
    criado_em      = Column(DateTime, default=datetime.utcnow)


# ── Comprovantes de pagamento (arquivo guardado no banco) ──────────────────
class Comprovante(Base):
    __tablename__ = "comprovantes"
    id             = Column(Integer, primary_key=True, index=True)
    eletricista_id = Column(Integer, ForeignKey("eletricistas.id"), nullable=False, index=True)
    ano            = Column(Integer, nullable=False)
    mes            = Column(Integer, nullable=False)
    nome_arquivo   = Column(String, nullable=False)
    mime           = Column(String, nullable=False)
    tamanho        = Column(Integer, nullable=False)
    dados          = Column(LargeBinary, nullable=False)
    valor          = Column(Float)
    data_pagamento = Column(Date)
    observacao     = Column(String)
    criado_em      = Column(DateTime, default=datetime.utcnow)


# ── Notificações (sininho do app + push no celular) ─────────────────────────
class Notificacao(Base):
    __tablename__ = "notificacoes"
    id         = Column(Integer, primary_key=True, index=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False, index=True)
    tipo       = Column(String)            # diaria | obra | outro
    titulo     = Column(String, nullable=False)
    texto      = Column(String)
    link       = Column(String)            # tela do app a abrir
    lida       = Column(Boolean, default=False)
    criado_em  = Column(DateTime, default=datetime.utcnow)


class PushAssinatura(Base):
    __tablename__ = "push_assinaturas"
    id         = Column(Integer, primary_key=True, index=True)
    usuario_id = Column(Integer, ForeignKey("usuarios.id"), nullable=False, index=True)
    endpoint   = Column(Text, nullable=False, unique=True)
    p256dh     = Column(String, nullable=False)
    auth       = Column(String, nullable=False)
    criado_em  = Column(DateTime, default=datetime.utcnow)


class Config(Base):
    """Pares chave/valor do sistema (ex.: chaves VAPID do push)."""
    __tablename__ = "config"
    chave = Column(String, primary_key=True)
    valor = Column(Text)


def migrar_colunas(engine):
    """create_all() não altera tabelas que já existem; aqui adicionamos
    as colunas novas em bancos criados antes desta versão."""
    from sqlalchemy import inspect, text
    insp = inspect(engine)
    if "usuarios" in insp.get_table_names():
        cols = {c["name"] for c in insp.get_columns("usuarios")}
        novas = [("cargo", "VARCHAR"), ("eletricista_id", "INTEGER"), ("senha_padrao", "BOOLEAN DEFAULT FALSE")]
        for nome, tipo in novas:
            if nome not in cols:
                with engine.begin() as conn:
                    conn.execute(text(f"ALTER TABLE usuarios ADD COLUMN {nome} {tipo}"))
    if "eletricistas" in insp.get_table_names():
        cols = {c["name"] for c in insp.get_columns("eletricistas")}
        if "salario_fixo" not in cols:
            with engine.begin() as conn:
                conn.execute(text("ALTER TABLE eletricistas ADD COLUMN salario_fixo FLOAT DEFAULT 0"))
